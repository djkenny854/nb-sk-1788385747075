import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'app.lovable.c711b52337a1438faaab3a19751a450f',
  appName: 'skusers',
  webDir: 'dist',
  server: {
    // For development - connects to Lovable preview
    // Comment this out for production builds
    url: 'https://c711b523-37a1-438f-aaab-3a19751a450f.lovableproject.com?forceHideBadge=true',
    cleartext: true
  },
  plugins: {
    App: {
      // Deep link configuration
      appUrlOpen: {
        handlers: [
          {
            url: 'https://skusers.vercel.app',
            autoVerify: true
          }
        ]
      }
    },
    StatusBar: {
      style: 'dark',
      backgroundColor: '#000000'
    }
  },
  android: {
    allowMixedContent: true,
    captureInput: true,
    webContentsDebuggingEnabled: true
  },
  ios: {
    contentInset: 'automatic',
    scrollEnabled: true
  }
};

export default config;
