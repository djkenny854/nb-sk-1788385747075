
-- Fix the database constraint issues and relationship problems
-- Remove the problematic check constraint that's preventing order_tracking_id from being saved
ALTER TABLE pesapal_transactions DROP CONSTRAINT IF EXISTS pesapal_transactions_status_check;

-- Add a more flexible status constraint that allows all PesaPal status values
ALTER TABLE pesapal_transactions ADD CONSTRAINT pesapal_transactions_status_flexible_check 
CHECK (status IN ('pending', 'completed', 'failed', 'cancelled', 'processing', 'expired', 'Completed', 'Failed', 'Cancelled', 'Processing', 'Expired', 'COMPLETED', 'FAILED', 'CANCELLED', 'PROCESSING', 'EXPIRED'));

-- Add missing indexes for better performance
CREATE INDEX IF NOT EXISTS idx_pesapal_transactions_order_tracking_id ON pesapal_transactions(order_tracking_id);
CREATE INDEX IF NOT EXISTS idx_pesapal_transactions_merchant_reference ON pesapal_transactions(merchant_reference);
CREATE INDEX IF NOT EXISTS idx_pesapal_transactions_user_package ON pesapal_transactions(user_id, package_id);

-- Fix the foreign key relationship ambiguity between pesapal_transactions and packages
-- Drop existing foreign key if it exists
ALTER TABLE pesapal_transactions DROP CONSTRAINT IF EXISTS pesapal_transactions_package_id_fkey;
ALTER TABLE pesapal_transactions DROP CONSTRAINT IF EXISTS fk_pesapal_transactions_package_id;

-- Add a single, clear foreign key relationship
ALTER TABLE pesapal_transactions ADD CONSTRAINT pesapal_transactions_package_id_fkey 
FOREIGN KEY (package_id) REFERENCES packages(id) ON DELETE SET NULL;

-- Ensure payment_error_logs table can handle all error types
ALTER TABLE payment_error_logs DROP CONSTRAINT IF EXISTS payment_error_logs_error_type_check;

-- Add function to safely get package info for transactions
CREATE OR REPLACE FUNCTION get_transaction_package_info(p_package_id UUID)
RETURNS TABLE(name TEXT, duration_days INTEGER)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN QUERY
  SELECT p.name, p.duration_days
  FROM packages p
  WHERE p.id = p_package_id;
END;
$$;

-- Create function to find transaction by tracking ID or merchant reference
CREATE OR REPLACE FUNCTION find_pesapal_transaction(p_order_tracking_id TEXT, p_merchant_reference TEXT DEFAULT NULL)
RETURNS TABLE(
  id UUID,
  user_id UUID,
  package_id UUID,
  amount_ugx INTEGER,
  status TEXT,
  merchant_reference TEXT,
  order_tracking_id TEXT,
  phone_number TEXT,
  created_at TIMESTAMP WITH TIME ZONE,
  package_name TEXT,
  package_duration_days INTEGER
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- First try to find by order_tracking_id
  IF p_order_tracking_id IS NOT NULL THEN
    RETURN QUERY
    SELECT 
      pt.id,
      pt.user_id,
      pt.package_id,
      pt.amount_ugx,
      pt.status,
      pt.merchant_reference,
      pt.order_tracking_id,
      pt.phone_number,
      pt.created_at,
      p.name as package_name,
      p.duration_days as package_duration_days
    FROM pesapal_transactions pt
    LEFT JOIN packages p ON p.id = pt.package_id
    WHERE pt.order_tracking_id = p_order_tracking_id;
    
    -- If found, return
    IF FOUND THEN
      RETURN;
    END IF;
  END IF;
  
  -- Fallback to merchant_reference if tracking_id didn't work
  IF p_merchant_reference IS NOT NULL THEN
    RETURN QUERY
    SELECT 
      pt.id,
      pt.user_id,
      pt.package_id,
      pt.amount_ugx,
      pt.status,
      pt.merchant_reference,
      pt.order_tracking_id,
      pt.phone_number,
      pt.created_at,
      p.name as package_name,
      p.duration_days as package_duration_days
    FROM pesapal_transactions pt
    LEFT JOIN packages p ON p.id = pt.package_id
    WHERE pt.merchant_reference = p_merchant_reference;
  END IF;
END;
$$;

-- Create a more robust extend_or_create_subscription function
CREATE OR REPLACE FUNCTION extend_or_create_subscription_robust(
  p_user_id UUID,
  p_package_id UUID,
  p_payment_reference TEXT,
  p_duration_days INTEGER
)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  existing_subscription_id UUID;
  new_end_date TIMESTAMP WITH TIME ZONE;
  subscription_id UUID;
  result JSON;
BEGIN
  -- Check for existing active subscription for this package
  SELECT id INTO existing_subscription_id
  FROM user_subscriptions
  WHERE user_id = p_user_id 
    AND package_id = p_package_id 
    AND is_active = true 
    AND end_date > NOW();

  IF existing_subscription_id IS NOT NULL THEN
    -- Extend existing subscription
    SELECT end_date INTO new_end_date
    FROM user_subscriptions
    WHERE id = existing_subscription_id;
    
    -- Add duration to existing end date
    new_end_date := new_end_date + (p_duration_days || ' days')::INTERVAL;
    
    UPDATE user_subscriptions
    SET 
      end_date = new_end_date,
      updated_at = NOW(),
      payment_reference = p_payment_reference
    WHERE id = existing_subscription_id;
    
    -- Create notification for extension
    INSERT INTO notifications (user_id, title, message, type)
    VALUES (
      p_user_id,
      'Subscription Extended! 🎉',
      'Your subscription has been extended by ' || p_duration_days || ' days. New expiry: ' || new_end_date::DATE,
      'success'
    );
    
    result := json_build_object(
      'success', true,
      'action', 'extended',
      'subscription_id', existing_subscription_id,
      'new_end_date', new_end_date
    );
  ELSE
    -- Create new subscription
    INSERT INTO user_subscriptions (
      user_id,
      package_id,
      start_date,
      end_date,
      payment_reference,
      is_active
    ) VALUES (
      p_user_id,
      p_package_id,
      NOW(),
      NOW() + (p_duration_days || ' days')::INTERVAL,
      p_payment_reference,
      true
    ) RETURNING id INTO subscription_id;
    
    -- Create welcome notification
    INSERT INTO notifications (user_id, title, message, type)
    VALUES (
      p_user_id,
      'Welcome to Premium! 🌟',
      'Your subscription is now active for ' || p_duration_days || ' days. Enjoy premium tips!',
      'success'
    );
    
    result := json_build_object(
      'success', true,
      'action', 'created',
      'subscription_id', subscription_id,
      'end_date', NOW() + (p_duration_days || ' days')::INTERVAL
    );
  END IF;
  
  RETURN result;
  
EXCEPTION WHEN OTHERS THEN
  RETURN json_build_object(
    'success', false,
    'error', SQLERRM,
    'error_code', SQLSTATE
  );
END;
$$;
