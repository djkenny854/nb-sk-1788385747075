-- Fix Critical Security Issue 1: Prevent public access to profiles table
-- Drop the existing policies and recreate with explicit deny for public access
DROP POLICY IF EXISTS "Users can view own profile" ON public.profiles;
DROP POLICY IF EXISTS "Users can update own profile" ON public.profiles;
DROP POLICY IF EXISTS "Admins can manage profiles" ON public.profiles;

-- Create explicit DENY policy for public access (executed first)
CREATE POLICY "Deny public access to profiles"
  ON public.profiles
  FOR SELECT
  USING (false);

-- Allow users to view only their own profile
CREATE POLICY "Users can view own profile"
  ON public.profiles
  FOR SELECT
  USING (auth.uid() = id);

-- Allow users to update only their own profile
CREATE POLICY "Users can update own profile"
  ON public.profiles
  FOR UPDATE
  USING (auth.uid() = id);

-- Allow admins to manage all profiles
CREATE POLICY "Admins can manage profiles"
  ON public.profiles
  FOR ALL
  USING (is_admin(auth.uid()));

-- Fix Critical Security Issue 2: Restrict webhook transaction updates
-- The current policy "Webhooks can update transaction status" uses USING (true)
-- This is a security risk - only service role should update via webhooks
DROP POLICY IF EXISTS "Webhooks can update transaction status" ON public.pesapal_transactions;

-- Create more secure policy that only allows service role to update
CREATE POLICY "Service role can update transactions"
  ON public.pesapal_transactions
  FOR UPDATE
  USING (auth.role() = 'service_role');

-- Fix function search_path for security (Phase 5 warnings)
-- These functions need explicit search_path set
ALTER FUNCTION public.extend_or_create_subscription(uuid, uuid, text, integer) 
  SET search_path = 'public';

ALTER FUNCTION public.extend_or_create_subscription_robust(uuid, uuid, text, integer) 
  SET search_path = 'public';

ALTER FUNCTION public.user_has_active_subscription(uuid) 
  SET search_path = 'public';

ALTER FUNCTION public.has_recent_pending_payment(uuid, uuid) 
  SET search_path = 'public';

ALTER FUNCTION public.is_admin(uuid) 
  SET search_path = 'public';

ALTER FUNCTION public.validate_ug_phone(text) 
  SET search_path = 'public';

ALTER FUNCTION public.normalize_ug_phone(text) 
  SET search_path = 'public';

ALTER FUNCTION public.prevent_edit_completed_tickets() 
  SET search_path = 'public';