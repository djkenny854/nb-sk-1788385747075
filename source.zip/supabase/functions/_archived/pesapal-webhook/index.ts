
import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

interface PesapalStatusResponse {
  payment_method: string;
  amount: number;
  created_date: string;
  confirmation_code: string;
  payment_status_description: string;
  description: string;
  message: string;
  payment_account: string;
  call_back_url: string;
  status_code: number;
  merchant_reference: string;
  account_number: string;
  status: string;
  error?: string;
}

const logError = async (supabase: any, error: any, context: string, params?: any) => {
  try {
    await supabase.from('payment_error_logs').insert({
      error_type: error.name || 'WEBHOOK_ERROR',
      error_message: error.message || String(error),
      error_details: {
        context,
        params,
        stack: error.stack,
        timestamp: new Date().toISOString()
      },
      function_name: 'pesapal-webhook'
    });
  } catch (logErr) {
    console.error('Failed to log webhook error:', logErr);
  }
};

const getValidToken = async (): Promise<string> => {
  const environment = Deno.env.get('PESAPAL_ENVIRONMENT') || 'sandbox';
  const consumerKey = Deno.env.get('PESAPAL_CONSUMER_KEY');
  const consumerSecret = Deno.env.get('PESAPAL_CONSUMER_SECRET');
  
  if (!consumerKey || !consumerSecret) {
    throw new Error('Missing PesaPal credentials');
  }

  const baseUrl = environment === 'live' 
    ? 'https://pay.pesapal.com/v3/api'
    : 'https://cybqa.pesapal.com/pesapalv3/api';

  const tokenResponse = await fetch(`${baseUrl}/Auth/RequestToken`, {
    method: 'POST',
    headers: {
      'Accept': 'application/json',
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      consumer_key: consumerKey,
      consumer_secret: consumerSecret,
    }),
  });

  if (!tokenResponse.ok) {
    const errorText = await tokenResponse.text();
    throw new Error(`Token request failed: ${tokenResponse.status} - ${errorText}`);
  }

  const tokenData = await tokenResponse.json();
  
  if (tokenData.error || !tokenData.token) {
    throw new Error(`Token error: ${tokenData.message || 'No token received'}`);
  }

  return tokenData.token;
};

const getTransactionStatus = async (token: string, orderTrackingId: string): Promise<PesapalStatusResponse> => {
  const environment = Deno.env.get('PESAPAL_ENVIRONMENT') || 'sandbox';
  const baseUrl = environment === 'live' 
    ? 'https://pay.pesapal.com/v3/api'
    : 'https://cybqa.pesapal.com/pesapalv3/api';

  const statusResponse = await fetch(`${baseUrl}/Transactions/GetTransactionStatus?orderTrackingId=${orderTrackingId}`, {
    method: 'GET',
    headers: {
      'Accept': 'application/json',
      'Authorization': `Bearer ${token}`,
    },
  });

  if (!statusResponse.ok) {
    const errorText = await statusResponse.text();
    throw new Error(`Status request failed: ${statusResponse.status} - ${errorText}`);
  }

  const statusData = await statusResponse.json();
  
  if (statusData.error) {
    throw new Error(`Status error: ${statusData.message || statusData.error}`);
  }

  return statusData;
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    const url = new URL(req.url);
    const orderTrackingId = url.searchParams.get('OrderTrackingId');
    const orderMerchantReference = url.searchParams.get('OrderMerchantReference');

    console.log(`🔔 Webhook received:`, {
      orderTrackingId,
      orderMerchantReference,
      method: req.method,
      allParams: Object.fromEntries(url.searchParams.entries())
    });

    if (!orderTrackingId) {
      throw new Error('Missing OrderTrackingId parameter');
    }

    // Find transaction by tracking ID or merchant reference
    let { data: transaction, error: transactionError } = await supabaseClient
      .from('pesapal_transactions')
      .select('*')
      .eq('order_tracking_id', orderTrackingId)
      .maybeSingle();

    // If not found by tracking ID, try merchant reference
    if (!transaction && orderMerchantReference) {
      const { data: altTransaction, error: altError } = await supabaseClient
        .from('pesapal_transactions')
        .select('*')
        .eq('merchant_reference', orderMerchantReference)
        .maybeSingle();
      
      transaction = altTransaction;
      transactionError = altError;
    }

    if (transactionError) {
      await logError(supabaseClient, transactionError, 'find_transaction', { orderTrackingId, orderMerchantReference });
      throw new Error('Database error finding transaction');
    }

    if (!transaction) {
      console.log(`⚠️ Transaction not found for tracking ID: ${orderTrackingId}`);
      // Return success to prevent PesaPal from retrying
      return new Response('Transaction not found', { 
        headers: corsHeaders, 
        status: 200 
      });
    }

    console.log(`📋 Found transaction: ${transaction.id} (Status: ${transaction.status})`);

    // Skip if already processed
    if (transaction.status === 'completed' || transaction.status === 'failed') {
      console.log(`✓ Transaction already processed with status: ${transaction.status}`);
      return new Response('Already processed', { 
        headers: corsHeaders, 
        status: 200 
      });
    }

    // Get fresh token and check transaction status
    const token = await getValidToken();
    const statusData = await getTransactionStatus(token, orderTrackingId);

    console.log(`📊 Transaction status from PesaPal:`, {
      status: statusData.status,
      payment_status_description: statusData.payment_status_description,
      payment_method: statusData.payment_method,
      amount: statusData.amount
    });

    // Update transaction with latest info
    const updateData: any = {
      payment_status_description: statusData.payment_status_description,
      payment_method: statusData.payment_method,
      pesapal_response: statusData,
      updated_at: new Date().toISOString()
    };

    let subscriptionResult = null;

    // Process based on status
    if (statusData.status === 'COMPLETED') {
      updateData.status = 'completed';
      
      // Get package details for subscription creation
      const { data: packageData, error: packageError } = await supabaseClient
        .from('packages')
        .select('duration_days')
        .eq('id', transaction.package_id)
        .single();

      if (packageError) {
        await logError(supabaseClient, packageError, 'get_package_for_subscription', { 
          packageId: transaction.package_id,
          transactionId: transaction.id 
        });
        throw new Error('Failed to get package details for subscription');
      }

      // Create or extend subscription using the database function
      try {
        const { data: subscriptionId, error: subscriptionError } = await supabaseClient
          .rpc('extend_or_create_subscription', {
            p_user_id: transaction.user_id,
            p_package_id: transaction.package_id,
            p_payment_reference: orderTrackingId,
            p_duration_days: packageData.duration_days
          });

        if (subscriptionError) {
          throw subscriptionError;
        }

        subscriptionResult = subscriptionId;
        console.log(`✅ Subscription created/extended: ${subscriptionId}`);

      } catch (subscriptionError) {
        await logError(supabaseClient, subscriptionError, 'create_extend_subscription', {
          userId: transaction.user_id,
          packageId: transaction.package_id,
          transactionId: transaction.id
        });
        
        // Don't fail the webhook, but log the error
        console.error('Subscription creation failed:', subscriptionError);
        updateData.last_error = `Subscription creation failed: ${subscriptionError.message}`;
      }

    } else if (statusData.status === 'FAILED' || statusData.status === 'INVALID') {
      updateData.status = 'failed';
      updateData.last_error = statusData.payment_status_description || 'Payment failed';
      
    } else {
      // Still pending or other status
      updateData.status = 'pending';
      console.log(`⏳ Transaction still pending: ${statusData.status}`);
    }

    // Update the transaction
    const { error: updateError } = await supabaseClient
      .from('pesapal_transactions')
      .update(updateData)
      .eq('id', transaction.id);

    if (updateError) {
      await logError(supabaseClient, updateError, 'update_transaction', { 
        transactionId: transaction.id,
        updateData 
      });
      throw new Error('Failed to update transaction');
    }

    console.log(`💾 Transaction updated successfully:`, {
      transactionId: transaction.id,
      newStatus: updateData.status,
      subscriptionId: subscriptionResult
    });

    return new Response(
      JSON.stringify({
        success: true,
        status: updateData.status,
        message: 'Webhook processed successfully',
        transaction_id: transaction.id,
        subscription_id: subscriptionResult
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      }
    );

  } catch (error) {
    console.error('🔥 Webhook processing error:', error);
    
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );
    
    await logError(supabaseClient, error, 'webhook_processing', { 
      url: req.url,
      method: req.method 
    });

    // Return 200 to prevent PesaPal from retrying
    return new Response(
      JSON.stringify({
        success: false,
        error: 'Webhook processing failed',
        message: error.message
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      }
    );
  }
});
