
import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

const logError = async (supabase: any, error: any, context: string, params?: any) => {
  try {
    await supabase.from('payment_error_logs').insert({
      error_type: 'INITIATE_PAYMENT_ERROR',
      error_message: JSON.stringify(error),
      error_details: {
        context,
        params,
        stack: error.stack,
        timestamp: new Date().toISOString()
      },
      function_name: 'initiate-pesapal-payment'
    });
  } catch (logErr) {
    console.error('❌ Failed to log error:', logErr);
  }
};

const getCurrentDomain = (): string => {
  // Always use the production domain for consistency
  const customDomain = Deno.env.get('CUSTOM_DOMAIN');
  if (customDomain) {
    return customDomain;
  }
  return 'https://skusers.vercel.app';
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    const { userId, packageId, amount, phoneNumber, description } = await req.json()
    
    console.log('🔍 Payment initiation request:', { userId, packageId, amount, phoneNumber, description })

    if (!userId || !packageId || !amount || !phoneNumber) {
      throw new Error('Missing required fields: userId, packageId, amount, phoneNumber')
    }

    // Get package details
    const { data: packageData, error: packageError } = await supabaseClient
      .from('packages')
      .select('name, duration_days')
      .eq('id', packageId)
      .single()

    if (packageError) {
      console.error('❌ Package lookup error:', packageError)
      throw new Error('Package not found')
    }

    // Format phone number
    let formattedPhone = phoneNumber.replace(/[^0-9]/g, '')
    if (formattedPhone.startsWith('07')) {
      formattedPhone = '256' + formattedPhone.substring(1)
    }
    if (formattedPhone.length === 9) {
      formattedPhone = '256' + formattedPhone
    }

    // Generate unique references
    const merchantReference = `SK_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`
    const currentDomain = getCurrentDomain()

    console.log('🔗 Using domain for callbacks:', currentDomain)

    // Clean up old pending transactions first (30+ minutes old)
    await supabaseClient.rpc('cleanup_old_pending_transactions')
    console.log('🧹 Cleaned up old pending transactions')

    // Check for recent pending payment (within 2 minutes) - Only block if truly recent
    const { data: recentTransactions, error: pendingCheckError } = await supabaseClient
      .from('pesapal_transactions')
      .select('id, created_at, status')
      .eq('user_id', userId)
      .eq('package_id', packageId)
      .eq('status', 'pending')
      .gte('created_at', new Date(Date.now() - 120000).toISOString()) // 2 minutes ago
      .order('created_at', { ascending: false })

    if (pendingCheckError) {
      console.error('❌ Pending check error:', pendingCheckError)
      await logError(supabaseClient, pendingCheckError, 'check_pending_payment', { userId, packageId })
      // Don't block payment on check error - allow it to proceed
    }

    if (recentTransactions && recentTransactions.length > 0) {
      console.log('⚠️ Found recent pending transaction:', recentTransactions[0])
      throw new Error('You have a recent pending payment. Please wait 2 minutes before trying again.')
    }
    
    console.log('✅ No recent pending transactions found, proceeding with payment')

    // Create transaction record first
    const { data: transaction, error: transactionError } = await supabaseClient
      .from('pesapal_transactions')
      .insert({
        user_id: userId,
        package_id: packageId,
        amount_ugx: amount,
        phone_number: formattedPhone,
        merchant_reference: merchantReference,
        description: description || `${packageData.name} - ${packageData.duration_days} days`,
        status: 'pending',
        callback_url: `${currentDomain}/pesapal-callback`,
        cancellation_url: `${currentDomain}/payment-cancel`
      })
      .select()
      .single()

    if (transactionError) {
      console.error('❌ Transaction creation error:', transactionError)
      await logError(supabaseClient, transactionError, 'create_transaction', { userId, packageId, amount })
      throw new Error('Failed to create transaction record')
    }

    console.log('✅ Transaction created:', transaction.id)
    console.log('✅ Callback URL set to:', `${currentDomain}/pesapal-callback`)
    console.log('✅ Cancellation URL set to:', `${currentDomain}/payment-cancel`)

    // Get PesaPal auth token
    const pesapalEnv = Deno.env.get('PESAPAL_ENVIRONMENT') || 'sandbox'
    const baseUrl = pesapalEnv === 'live' 
      ? 'https://pay.pesapal.com/v3/api'
      : 'https://cybqa.pesapal.com/pesapalv3/api'

    const authResponse = await fetch(`${baseUrl}/Auth/RequestToken`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      body: JSON.stringify({
        consumer_key: Deno.env.get('PESAPAL_CONSUMER_KEY'),
        consumer_secret: Deno.env.get('PESAPAL_CONSUMER_SECRET')
      })
    })

    if (!authResponse.ok) {
      const authError = `Token request failed: ${authResponse.status}`
      console.error('❌', authError)
      await logError(supabaseClient, authError, 'pesapal_auth', { userId, packageId })
      throw new Error(authError)
    }

    const authData = await authResponse.json()
    console.log('✅ PesaPal auth successful')

    // Submit payment order
    const orderPayload = {
      id: merchantReference,
      currency: 'UGX',
      amount: amount,
      description: description || `${packageData.name} - ${packageData.duration_days} days`,
      callback_url: `${currentDomain}/pesapal-callback`,
      cancellation_url: `${currentDomain}/payment-cancel`,
      notification_id: Deno.env.get('PESAPAL_IPN_ID'),
      billing_address: {
        phone_number: formattedPhone,
        country_code: 'UG'
      }
    }

    console.log('📤 Submitting order with URLs:', {
      callback_url: orderPayload.callback_url,
      cancellation_url: orderPayload.cancellation_url
    })

    const orderResponse = await fetch(`${baseUrl}/Transactions/SubmitOrderRequest`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': `Bearer ${authData.token}`
      },
      body: JSON.stringify(orderPayload)
    })

    if (!orderResponse.ok) {
      const orderError = `Order submission failed: ${orderResponse.status}`
      console.error('❌', orderError)
      await logError(supabaseClient, orderError, 'pesapal_order', { userId, packageId, orderPayload })
      throw new Error(orderError)
    }

    const orderData = await orderResponse.json()
    console.log('📋 Order response:', orderData)

    // Update transaction with order tracking ID immediately
    const { error: updateError } = await supabaseClient
      .from('pesapal_transactions')
      .update({
        order_tracking_id: orderData.order_tracking_id,
        pesapal_response: orderData,
        token_used: authData.token
      })
      .eq('id', transaction.id)

    if (updateError) {
      console.error('❌ Failed to update transaction with tracking ID:', updateError)
      await logError(supabaseClient, updateError, 'update_tracking_id', { 
        transactionId: transaction.id,
        orderTrackingId: orderData.order_tracking_id 
      })
    }

    console.log('✅ Payment initiated successfully')
    console.log('🔗 Redirect URL:', orderData.redirect_url)

    return new Response(
      JSON.stringify({
        success: true,
        payment_url: orderData.redirect_url,
        order_tracking_id: orderData.order_tracking_id,
        merchant_reference: merchantReference
      }),
      { 
        headers: { 
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      }
    )

  } catch (error: any) {
    console.error('💥 Payment initiation error:', error)
    
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )
    
    await logError(supabaseClient, error, 'payment_initiation_critical')
    
    return new Response(
      JSON.stringify({
        success: false,
        error: error.message || 'Payment initiation failed'
      }),
      { 
        status: 500,
        headers: { 
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      }
    )
  }
})
