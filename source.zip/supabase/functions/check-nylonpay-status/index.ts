import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    let reference: string | null = null;
    if (req.method === "GET") {
      const url = new URL(req.url);
      reference = url.searchParams.get("reference");
    } else {
      const body = await req.json().catch(() => ({}));
      reference = body?.reference ?? null;
    }
    if (!reference) throw new Error("Missing reference");

    const { data, error } = await supabase
      .from("nylonpay_transactions")
      .select("id, status, reference, amount_ugx, error, updated_at")
      .eq("reference", reference)
      .single();
    if (error) throw new Error(error.message);

    if (["success", "successful", "completed"].includes(String(data.status).toLowerCase())) {
      await supabase.from("nylonpay_transactions").update({ status: "completed" }).eq("id", data.id);
      data.status = "completed";
    }

    return new Response(
      JSON.stringify({ success: true, ...data }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error: any) {
    return new Response(
      JSON.stringify({ success: false, error: error?.message ?? "Status check failed" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
