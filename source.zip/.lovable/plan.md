
## Goal
Replace the active Pesapal payment flow with Nylon Pay (`@nile-squad/nylonpay-ts`) while archiving (not deleting) the Pesapal code so it can be restored if needed.

## Nylon Pay flow (from docs)
- Server-side SDK; must run in an edge function (never expose `apiSecret` to the client).
- `nylonpay.collectPayment({ amount, currency:'UGX', customer:{name, phoneNumber}, description, reference, method:'mobileMoney', metadata })` returns a `PaymentInstance`.
- Real-time status via `payment.on('success' | 'failed' | 'error', ...)` or `await payment.wait()` for terminal state.
- Phone numbers auto-normalize to `256XXXXXXXXX`.
- Reference is any UUID; we'll pass our own to correlate with our transaction row.

## Secrets needed
- `NYLONPAY_API_KEY` (`npk_...`)
- `NYLONPAY_API_SECRET` (`nps_...`)
Requested via `add_secret` after user confirms.

## Database
New migration adds `public.nylonpay_transactions`:
```
id uuid pk, user_id uuid, package_id uuid, reference uuid unique,
amount_ugx int, currency text default 'UGX', phone_number text,
status text default 'pending',   -- pending | completed | failed | expired
nylonpay_transaction_id text, provider text, method text,
description text, metadata jsonb, error text,
created_at, updated_at
```
With `GRANT`s (`authenticated` select/insert; `service_role` all), RLS enabled, policies: user can select own rows; service_role writes. Reuses existing `extend_or_create_subscription_robust` on success.

## Edge functions
1. `initiate-nylonpay-payment` (verify_jwt=false, validated in code):
   - Validates body with Zod (`userId`, `packageId`, `amount>=500`, `phoneNumber`).
   - Fetches package, generates `reference = crypto.randomUUID()`.
   - Inserts `nylonpay_transactions` row with `status='pending'`.
   - Calls `nylonpay.collectPayment({...})`, awaits initial ack, returns `{ success, reference, transactionId }`.
   - Kicks off `payment.wait()` and, on terminal state, updates the row + calls `extend_or_create_subscription_robust` on success. (Handled with `EdgeRuntime.waitUntil` so response returns fast.)
2. `check-nylonpay-status` (polling fallback):
   - Given `reference`, returns current row status from DB. Frontend polls every 3s until terminal.
3. `nylonpay-webhook` (optional stub) — kept simple: signature check + status update, ready for when Nylon Pay webhook config is added.

## Frontend
- New `src/hooks/useNylonPayment.tsx`: initiates payment, polls status, shows toasts, triggers `PaymentSuccessModal` on completion. Replaces `usePaymentStatus` usage in `PackagesTab` / `XSubscriptionModal`.
- `PackagesTab.tsx` + `XSubscriptionModal.tsx`: swap `initiate-pesapal-payment` invoke → `initiate-nylonpay-payment`. No redirect/iframe — Nylon Pay is a phone-prompt flow, so we show an inline "Approve the prompt on your phone" modal with a spinner and live status.
- `useTransactions.tsx`: read from `nylonpay_transactions` instead of `pesapal_transactions`.
- Remove Pesapal callback/cancel redirect UI usage from the active app routes; keep the pages so archived flow still resolves.

## Archive Pesapal (don't delete)
- Move `supabase/functions/initiate-pesapal-payment`, `pesapal-callback`, `pesapal-webhook`, `pesapal-webhook-production`, `check-payment-status`, `cancel-pending-payment` to `supabase/functions/_archived/pesapal/` and remove them from `supabase/config.toml` so they aren't deployed.
- Move `src/hooks/usePaymentStatus.tsx`, `src/pages/PesapalCallback.tsx`, `src/pages/PaymentCancel.tsx`, `src/pages/PaymentSuccess.tsx` (Pesapal-specific bits) to `src/_archived/pesapal/` and drop their routes from `src/App.tsx`.
- Leave `pesapal_transactions` table in place (historical data). No destructive SQL.
- Add `src/_archived/README.md` explaining how to restore.

## Testing checklist
1. Build passes (`tsgo`).
2. `supabase--curl_edge_functions` POST `/initiate-nylonpay-payment` with a test user/package → expect `pending` row.
3. Poll `/check-nylonpay-status?reference=...`.
4. UI: subscribe flow shows "Check your phone" modal, then success confetti + subscription active.

## Out of scope
- Bank/card methods (mobile money only for launch).
- Live webhook signing (stub only until provider dashboard is configured).
