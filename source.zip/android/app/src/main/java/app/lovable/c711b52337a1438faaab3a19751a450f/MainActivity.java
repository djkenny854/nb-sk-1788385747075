package app.lovable.c711b52337a1438faaab3a19751a450f;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
