
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "next-themes";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { HashRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "@/hooks/useAuth";
import { useMaintenanceMode } from "@/hooks/useMaintenanceMode";
import { MaintenanceMode } from "@/components/MaintenanceMode";
import { useBannedAccountCheck } from "@/hooks/useBannedAccountCheck";
import { BannedAccountModal } from "@/components/BannedAccountModal";
import { useThemeColorMeta } from "@/hooks/useThemeColorMeta";
import { APP_CONFIG } from "@/config/appConfig";
import { useCapacitorBackButton } from '@/hooks/useCapacitorBackButton';
import { useDeepLinks } from '@/hooks/useDeepLinks';
import { useStatusBar } from '@/hooks/useStatusBar';

import Index from "./pages/Index";
import Auth from "./pages/Auth";
import Landing from "./pages/Landing";
import Contact from "./pages/Contact";
import Plans from "./pages/Plans";
import FreeTips from "./pages/FreeTips";
import HelpCenter from "./pages/HelpCenter";
import TermsOfService from "./pages/TermsOfService";
import ResetPassword from "./pages/ResetPassword";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

// Component that uses router hooks - must be inside HashRouter
function CapacitorIntegration() {
  useCapacitorBackButton();
  useDeepLinks();
  useStatusBar();
  
  return null;
}

function AppRoutes() {
  const { isMaintenanceMode } = useMaintenanceMode();
  const { showBannedModal, setShowBannedModal } = useBannedAccountCheck();

  if (isMaintenanceMode) {
    return <MaintenanceMode />;
  }

  return (
    <>
      <CapacitorIntegration />
      <Routes>
        {/* Conditionally show Landing or Auth as the entry point */}
        <Route path="/" element={APP_CONFIG.showLandingPage ? <Landing /> : <Auth />} />
        <Route path="/auth" element={<Auth />} />
        <Route path="/landing" element={<Landing />} />
        <Route path="/app/*" element={<Index />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/plans" element={<Plans />} />
        <Route path="/free-tips" element={<FreeTips />} />
        <Route path="/help" element={<HelpCenter />} />
        <Route path="/terms" element={<TermsOfService />} />
        <Route path="/reset-password" element={<ResetPassword />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
      <BannedAccountModal 
        isOpen={showBannedModal} 
        onClose={() => setShowBannedModal(false)} 
      />
    </>
  );
}

function AppContent() {
  useThemeColorMeta();
  return (
    <HashRouter>
      <AppRoutes />
    </HashRouter>
  );
}

const App = () => {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <ThemeProvider
          attribute="class"
          defaultTheme="light"
          enableSystem={false}
          disableTransitionOnChange={false}
        >
          <TooltipProvider>
            <Toaster />
            <Sonner />
            <AppContent />
          </TooltipProvider>
        </ThemeProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
};

export default App;
