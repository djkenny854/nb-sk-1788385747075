
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

export const useMaintenanceMode = () => {
  const [isMaintenanceMode, setIsMaintenanceMode] = useState(false);
  const [loading, setLoading] = useState(true);

  const checkMaintenanceMode = async () => {
    try {
      console.log('Checking maintenance mode...');
      
      const { data, error } = await supabase
        .from('system_settings')
        .select('value')
        .eq('key', 'maintenance_mode')
        .single();

      if (error && error.code !== 'PGRST116') {
        console.error('Error checking maintenance mode:', error);
        setIsMaintenanceMode(false);
        setLoading(false);
        return;
      }

      let maintenanceEnabled = false;
      if (data?.value) {
        console.log('Raw maintenance value:', data.value, typeof data.value);
        
        // Handle boolean value directly
        if (typeof data.value === 'boolean') {
          maintenanceEnabled = data.value;
        } 
        // Handle string boolean values
        else if (typeof data.value === 'string') {
          maintenanceEnabled = ['true', '1', 'yes', 'on', 'enabled'].includes(data.value.toLowerCase());
        } 
        // Handle number values
        else if (typeof data.value === 'number') {
          maintenanceEnabled = data.value === 1;
        }
        // Handle object values (JSON)
        else if (typeof data.value === 'object' && data.value !== null) {
          // Check for various possible object structures
          if ('enabled' in data.value) {
            maintenanceEnabled = Boolean(data.value.enabled);
          } else if ('maintenance_mode' in data.value) {
            maintenanceEnabled = Boolean(data.value.maintenance_mode);
          } else if ('value' in data.value) {
            maintenanceEnabled = Boolean(data.value.value);
          } else {
            // Fallback: check if any property indicates maintenance is on
            maintenanceEnabled = Object.values(data.value).some(v => 
              v === true || v === 'true' || v === 1 || v === '1'
            );
          }
        }
      }
      
      console.log('Maintenance mode status:', maintenanceEnabled);
      
      setIsMaintenanceMode(maintenanceEnabled);
      setLoading(false);
    } catch (error) {
      console.error('Maintenance mode check failed:', error);
      setIsMaintenanceMode(false);
      setLoading(false);
    }
  };

  useEffect(() => {
    // Initial check
    checkMaintenanceMode();

    // Set up real-time subscription for maintenance mode changes
    const channel = supabase
      .channel('maintenance-mode-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'system_settings',
          filter: 'key=eq.maintenance_mode'
        },
        (payload) => {
          console.log('Real-time maintenance mode change detected:', payload);
          // Re-check maintenance mode when changes are detected
          checkMaintenanceMode();
        }
      )
      .subscribe((status) => {
        console.log('Maintenance mode subscription status:', status);
      });

    // Check every 5 seconds for immediate response
    const interval = setInterval(checkMaintenanceMode, 5000);

    return () => {
      console.log('Cleaning up maintenance mode subscriptions');
      supabase.removeChannel(channel);
      clearInterval(interval);
    };
  }, []);

  return { isMaintenanceMode, loading };
};
