
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

interface FreeTicketMatch {
  id: string;
  match_name: string;
  match_time: string;
  prediction: string;
  odds: string;
}

interface FreeTicket {
  id: string;
  ticket_name: string;
  status: string;
  comments: string | null;
  betika_link: string | null;
  betpawa_link: string | null;
  created_at: string;
  updated_at: string;
  matches: FreeTicketMatch[];
}

export function useFreeTickets() {
  const [freeTickets, setFreeTickets] = useState<FreeTicket[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchFreeTickets();
    const cleanup = setupRealtimeSubscription();
    return cleanup;
  }, []);

  const fetchFreeTickets = async () => {
    try {
      console.log('🎫 Fetching free tickets with matches');
      
      // Get free tickets with their matches
      const { data: ticketsData, error: ticketsError } = await supabase
        .from('free_tickets')
        .select(`
          id,
          ticket_name,
          status,
          comments,
          betika_link,
          betpawa_link,
          created_at,
          updated_at
        `)
        .order('created_at', { ascending: false })
        .limit(10);

      if (ticketsError) {
        console.error('❌ Error fetching free tickets:', ticketsError);
        setFreeTickets([]);
        setLoading(false);
        return;
      }

      // Get matches for each ticket
      const ticketsWithMatches = await Promise.all(
        (ticketsData || []).map(async (ticket) => {
          const { data: matchesData, error: matchesError } = await supabase
            .from('free_ticket_matches')
            .select(`
              id,
              match_name,
              match_time,
              prediction,
              odds
            `)
            .eq('free_ticket_id', ticket.id)
            .order('match_time', { ascending: true });

          if (matchesError) {
            console.error('❌ Error fetching matches for ticket:', ticket.id, matchesError);
            return { ...ticket, matches: [] };
          }

          return {
            ...ticket,
            matches: matchesData || []
          };
        })
      );

      console.log('🎫 Free tickets with matches fetched:', ticketsWithMatches);
      setFreeTickets(ticketsWithMatches);
    } catch (error) {
      console.error('💥 Error fetching free tickets:', error);
      setFreeTickets([]);
    }
    setLoading(false);
  };

  const setupRealtimeSubscription = () => {
    console.log('🎫 Setting up realtime subscription for free tickets');
    
    const channel = supabase
      .channel(`free-tickets-realtime-${Math.random().toString(36).slice(2)}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'free_tickets'
        },
        (payload) => {
          console.log('🎫 Free ticket realtime event:', payload);
          fetchFreeTickets();
        }
      )
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'free_ticket_matches'
        },
        (payload) => {
          console.log('🎫 Free ticket match realtime event:', payload);
          fetchFreeTickets();
        }
      )
      .subscribe();

    return () => {
      console.log('🎫 Cleaning up free ticket subscription');
      supabase.removeChannel(channel);
    };
  };

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'won':
        return 'bg-green-100 text-green-800';
      case 'lost':
        return 'bg-red-100 text-red-800';
      case 'pending':
        return 'bg-gray-100 text-gray-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status.toLowerCase()) {
      case 'won':
        return '🏆';
      case 'lost':
        return '❌';
      case 'pending':
        return '⏳';
      default:
        return '📝';
    }
  };

  return {
    freeTickets,
    loading,
    getStatusColor,
    getStatusIcon,
    refetch: fetchFreeTickets
  };
}
