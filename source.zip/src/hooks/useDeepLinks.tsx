import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { App, URLOpenListenerEvent } from '@capacitor/app';
import { Capacitor } from '@capacitor/core';

/**
 * Hook to handle deep links in Capacitor apps.
 * Routes incoming URLs (from OAuth, payments, etc.) to the correct page.
 */
export function useDeepLinks() {
  const navigate = useNavigate();

  useEffect(() => {
    // Only run on native platforms
    if (!Capacitor.isNativePlatform()) {
      return;
    }

    const handleAppUrlOpen = (event: URLOpenListenerEvent) => {
      console.log('Deep link received:', event.url);
      
      try {
        const url = new URL(event.url);
        const pathname = url.pathname;
        const search = url.search;
        const hash = url.hash;

        // Handle different deep link routes
        if (pathname.includes('/auth') || pathname === '/auth') {
          // OAuth callback - navigate to auth page with hash (contains tokens)
          navigate(`/auth${hash || search}`);
        } else if (pathname.includes('/pesapal-callback')) {
          // Pesapal payment callback
          const params = new URLSearchParams(search);
          const orderTrackingId = params.get('OrderTrackingId');
          const merchantReference = params.get('OrderMerchantReference');
          
          if (orderTrackingId) {
            navigate(`/pesapal-callback?OrderTrackingId=${orderTrackingId}${merchantReference ? `&OrderMerchantReference=${merchantReference}` : ''}`);
          } else {
            navigate('/pesapal-callback' + search);
          }
        } else if (pathname.includes('/payment-success')) {
          navigate('/payment-success' + search);
        } else if (pathname.includes('/payment-cancel')) {
          navigate('/payment-cancel' + search);
        } else if (pathname.includes('/reset-password')) {
          navigate('/reset-password' + hash);
        } else {
          // Default: navigate to the path
          navigate(pathname + search + hash);
        }
      } catch (error) {
        console.error('Error parsing deep link URL:', error);
        // Fallback to home
        navigate('/app');
      }
    };

    // Listen for app URL open events
    const urlOpenListener = App.addListener('appUrlOpen', handleAppUrlOpen);

    // Also check if the app was opened with a URL
    App.getLaunchUrl().then((launchUrl) => {
      if (launchUrl?.url) {
        console.log('App launched with URL:', launchUrl.url);
        handleAppUrlOpen({ url: launchUrl.url });
      }
    });

    // Cleanup listener on unmount
    return () => {
      urlOpenListener.then(listener => listener.remove());
    };
  }, [navigate]);
}
