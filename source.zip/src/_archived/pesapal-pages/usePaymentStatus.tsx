
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';

interface PaymentStatusHook {
  checkPaymentStatus: (orderTrackingId: string) => Promise<boolean>;
  loading: boolean;
}

export function usePaymentStatus(): PaymentStatusHook {
  const [loading, setLoading] = useState(false);

  const checkPaymentStatus = async (orderTrackingId: string): Promise<boolean> => {
    setLoading(true);
    
    try {
      console.log('🔍 Checking payment status for:', orderTrackingId);
      
      const { data, error } = await supabase.functions.invoke('check-payment-status', {
        body: { orderTrackingId }
      });

      if (error) {
        console.error('❌ Payment status check error:', error);
        toast({
          title: "Payment Check Failed",
          description: "Unable to verify payment status. Please try again.",
          variant: "destructive"
        });
        return false;
      }

      console.log('📊 Payment status response:', data);

      if (data.success && data.status === 'completed') {
        toast({
          title: "Payment Successful! 🎉",
          description: "Your subscription has been activated successfully.",
        });
        return true;
      } else if (data.status === 'failed') {
        toast({
          title: "Payment Failed",
          description: "Your payment was not successful. Please try again.",
          variant: "destructive"
        });
        return false;
      } else if (data.status === 'payment_success_db_error') {
        toast({
          title: "Payment Successful",
          description: "We're verifying your subscription. Please wait a moment.",
        });
        return false;
      } else {
        toast({
          title: "Payment Pending",
          description: "Your payment is still being processed. Please wait.",
        });
        return false;
      }
    } catch (error) {
      console.error('💥 Payment status check error:', error);
      toast({
        title: "Error Checking Payment",
        description: "An error occurred while checking payment status.",
        variant: "destructive"
      });
      return false;
    } finally {
      setLoading(false);
    }
  };

  return {
    checkPaymentStatus,
    loading
  };
}
