import { useState, useEffect, useRef } from 'react';
import { AlertCircle, X, CheckCircle, CreditCard, Shield, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { useNavigate } from 'react-router-dom';
import { usePaymentStatus } from '@/hooks/usePaymentStatus';
import { supabase } from '@/integrations/supabase/client';
import { cn } from '@/lib/utils';

interface PaymentLoaderProps {
  paymentUrl?: string;
  onClose?: () => void;
  onProcessPayment?: () => Promise<string | { payment_url: string; order_tracking_id: string }>;
  onPaymentSuccess?: () => void;
}

export function PaymentLoader({ paymentUrl, onClose, onProcessPayment, onPaymentSuccess }: PaymentLoaderProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [showIframe, setShowIframe] = useState(false);
  const [iframeLoaded, setIframeLoaded] = useState(false);
  const [iframeError, setIframeError] = useState(false);
  const [processingError, setProcessingError] = useState<string | null>(null);
  const [finalPaymentUrl, setFinalPaymentUrl] = useState(paymentUrl);
  const [orderTrackingId, setOrderTrackingId] = useState<string | null>(null);
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const navigate = useNavigate();
  const { checkPaymentStatus } = usePaymentStatus();
  const pollingIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const hasProcessedRef = useRef(false);

  const steps = [
    { icon: Shield, text: "Validating your details...", duration: 1000 },
    { icon: CreditCard, text: "Connecting to payment gateway...", duration: 1500 },
    { icon: Loader2, text: "Preparing secure checkout...", duration: 1000 },
    { icon: CheckCircle, text: "Redirecting to PesaPal...", duration: 800 }
  ];

  useEffect(() => {
    // Prevent double execution (React StrictMode causes double render in dev)
    if (hasProcessedRef.current) {
      console.log('⚠️ Payment processing already started, skipping duplicate effect');
      return;
    }

    const processPayment = async () => {
      hasProcessedRef.current = true;
      let capturedPaymentUrl: string | null = null;
      let capturedTrackingId: string | null = null;
      
      try {
        // Process through steps
        for (let i = 0; i < steps.length; i++) {
          setCurrentStep(i);
          await new Promise(resolve => setTimeout(resolve, steps[i].duration));
          
          // If we need to process payment (no paymentUrl provided initially)
          if (i === 1 && onProcessPayment && !paymentUrl) {
            console.log('🔄 Calling onProcessPayment...');
            const result = await onProcessPayment();
            console.log('💳 Payment URL received:', result);
            if (typeof result === 'string') {
              capturedPaymentUrl = result;
              setFinalPaymentUrl(result);
              console.log('✅ Payment URL set (string):', result);
            } else {
              capturedPaymentUrl = result.payment_url;
              capturedTrackingId = result.order_tracking_id;
              setFinalPaymentUrl(result.payment_url);
              setOrderTrackingId(result.order_tracking_id);
              console.log('✅ Payment URL set (object):', result.payment_url);
              console.log('📋 Order tracking ID set:', result.order_tracking_id);
            }
          }
        }
        
        // Show iframe after all steps complete - use captured value
        const urlToUse = capturedPaymentUrl || paymentUrl || finalPaymentUrl;
        console.log('🎬 Steps complete. Payment URL to use:', urlToUse);
        if (urlToUse) {
          console.log('✅ Showing iframe with URL:', urlToUse);
          setShowIframe(true);
        } else {
          console.error('❌ No payment URL available, cannot show iframe');
          setProcessingError('Payment URL not received. Please try again.');
        }
      } catch (error: any) {
        console.error('Payment processing error:', error);
        setProcessingError(error.message || 'Failed to process payment');
      }
    };

    processPayment();
    
    // Cleanup function
    return () => {
      // Don't reset on cleanup to prevent re-runs
    };
  }, []); // Empty deps - only run once

  // Poll payment status when tracking ID is available, but with delay
  useEffect(() => {
    if (!orderTrackingId || !showIframe) return;

    console.log('🔄 Payment iframe opened, will start status polling after 30 seconds');
    
    // Wait 30 seconds before starting to poll (give user time to interact with iframe)
    const initialDelay = setTimeout(() => {
      console.log('🔄 Starting payment status polling for:', orderTrackingId);
      
      // Poll every 10 seconds after initial delay
      pollingIntervalRef.current = setInterval(async () => {
        console.log('🔍 Polling payment status...');
        const success = await checkPaymentStatus(orderTrackingId);
        
        if (success) {
          console.log('✅ Payment confirmed via polling');
          if (pollingIntervalRef.current) {
            clearInterval(pollingIntervalRef.current);
          }
          onPaymentSuccess?.();
          onClose?.();
        }
      }, 10000);
    }, 30000); // 30 second initial delay

    return () => {
      clearTimeout(initialDelay);
      if (pollingIntervalRef.current) {
        clearInterval(pollingIntervalRef.current);
      }
    };
  }, [orderTrackingId, showIframe, checkPaymentStatus, navigate, onClose]);

  useEffect(() => {
    if (!showIframe || !iframeRef.current) return;

    // Listen for iframe navigation and URL changes
    const checkIframeUrl = () => {
      try {
        const iframe = iframeRef.current;
        if (!iframe) return;

        // Check if we can access the iframe's location
        const iframeUrl = iframe.contentWindow?.location?.href;
        console.log('Checking iframe URL:', iframeUrl);
        
        if (iframeUrl) {
          if (iframeUrl.includes('/payment-success')) {
            console.log('Payment success detected');
            onPaymentSuccess?.();
            onClose?.();
          } else if (iframeUrl.includes('/payment-cancel')) {
            console.log('Payment cancel detected');
            onClose?.();
          }
        }
      } catch (error) {
        // Cross-origin restrictions prevent access, this is expected
        console.log('Cross-origin restriction, relying on other methods');
      }
    };

    // Check URL periodically
    const interval = setInterval(checkIframeUrl, 1000);
    
    // Listen for postMessage events from the iframe
    const handleMessage = (event: MessageEvent) => {
      console.log('Received message from iframe:', event);
      
      if (event.data?.type === 'payment-success') {
        console.log('Payment success via postMessage');
        onPaymentSuccess?.();
        onClose?.();
      } else if (event.data?.type === 'payment-cancel') {
        console.log('Payment cancel via postMessage');
        onClose?.();
      }
    };

    // Listen for browser navigation changes (when PesaPal redirects)
    const handlePopState = () => {
      const currentUrl = window.location.href;
      console.log('PopState event, current URL:', currentUrl);
      
      if (currentUrl.includes('/payment-success')) {
        console.log('Payment success detected via popstate');
        onClose?.();
        navigate('/payment-success');
      } else if (currentUrl.includes('/payment-cancel')) {
        console.log('Payment cancel detected via popstate');
        onClose?.();
        navigate('/payment-cancel');
      }
    };

    // Listen for focus events (when user returns to the tab)
    const handleFocus = () => {
      const currentUrl = window.location.href;
      console.log('Window focus, checking URL:', currentUrl);
      
      if (currentUrl.includes('/payment-success') || currentUrl.includes('/payment-cancel')) {
        setTimeout(checkIframeUrl, 500); // Small delay to let iframe settle
      }
    };

    window.addEventListener('message', handleMessage);
    window.addEventListener('popstate', handlePopState);
    window.addEventListener('focus', handleFocus);

    return () => {
      clearInterval(interval);
      window.removeEventListener('message', handleMessage);
      window.removeEventListener('popstate', handlePopState);
      window.removeEventListener('focus', handleFocus);
    };
  }, [showIframe, navigate, onClose]);

  const handleIframeError = () => {
    setIframeError(true);
  };

  const handleClose = async () => {
    // Clean up polling
    if (pollingIntervalRef.current) {
      clearInterval(pollingIntervalRef.current);
    }
    
    onClose?.();
  };

  const handleRetry = () => {
    setIframeError(false);
    setProcessingError(null);
    setShowIframe(false);
    setCurrentStep(0);
    setOrderTrackingId(null);
    if (pollingIntervalRef.current) {
      clearInterval(pollingIntervalRef.current);
    }
    // Restart the flow
    setTimeout(() => {
      const processPayment = async () => {
        try {
          for (let i = 0; i < steps.length; i++) {
            setCurrentStep(i);
            await new Promise(resolve => setTimeout(resolve, steps[i].duration));
          }
          if (finalPaymentUrl) {
            setShowIframe(true);
          }
        } catch (error: any) {
          setProcessingError(error.message || 'Failed to process payment');
        }
      };
      processPayment();
    }, 500);
  };

  // Only show error if we're not showing the iframe (prevents error modal over iframe)
  if (processingError && !showIframe) {
    return (
      <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
        <div className="bg-background rounded-lg shadow-2xl text-center space-y-6 max-w-md mx-auto p-8 relative">
          {onClose && (
            <Button
              onClick={handleClose}
              variant="ghost"
              size="sm"
              className="absolute top-4 right-4"
            >
              <X className="w-4 h-4" />
            </Button>
          )}
          
          <div className="w-16 h-16 bg-destructive/10 rounded-full flex items-center justify-center mx-auto">
            <AlertCircle className="w-8 h-8 text-destructive" />
          </div>
          
          <div className="space-y-2">
            <h2 className="text-2xl font-bold text-foreground">Payment Error</h2>
            <p className="text-muted-foreground">{processingError}</p>
          </div>
          
          <div className="flex gap-3 justify-center">
            <Button onClick={handleRetry} variant="default">
              Try Again
            </Button>
            {onClose && (
              <Button onClick={handleClose} variant="outline">
                Go Back
              </Button>
            )}
          </div>
        </div>
      </div>
    );
  }

  if (iframeError) {
    return (
      <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
        <div className="bg-background rounded-lg shadow-2xl text-center space-y-6 max-w-md mx-auto p-8 relative">
          {onClose && (
            <Button
              onClick={handleClose}
              variant="ghost"
              size="sm"
              className="absolute top-4 right-4"
            >
              <X className="w-4 h-4" />
            </Button>
          )}
          
          <div className="w-16 h-16 bg-destructive/10 rounded-full flex items-center justify-center mx-auto">
            <AlertCircle className="w-8 h-8 text-destructive" />
          </div>
          
          <div className="space-y-2">
            <h2 className="text-2xl font-bold text-foreground">Payment Load Error</h2>
            <p className="text-muted-foreground">
              Could not load PesaPal checkout. Please check your internet connection and try again.
            </p>
          </div>
          
          <div className="flex gap-3 justify-center">
            <Button onClick={handleRetry} variant="default">
              Try Again
            </Button>
            {onClose && (
              <Button onClick={handleClose} variant="outline">
                Go Back
              </Button>
            )}
          </div>
        </div>
      </div>
    );
  }

  if (!showIframe) {
    const currentStepData = steps[currentStep];
    const IconComponent = currentStepData?.icon || Loader2;
    
    return (
      <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
        <div className="bg-background rounded-2xl shadow-2xl text-center max-w-[calc(100%-2rem)] sm:max-w-md mx-auto overflow-hidden">
          {/* Header */}
          <div className="flex items-center justify-between px-4 py-3 border-b border-border">
            {onClose && (
              <button
                onClick={handleClose}
                className="p-2 -m-2 rounded-full hover:bg-muted transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            )}
            <h2 className="font-bold text-base flex-1 text-center">Processing</h2>
            <div className="w-9" />
          </div>
          
          <div className="p-6 space-y-6">
            {/* Animated Icon Container */}
            <div className="relative">
              <div className="w-20 h-20 bg-gradient-to-br from-primary/20 to-primary/5 rounded-full flex items-center justify-center mx-auto">
                <div className="w-16 h-16 bg-gradient-to-br from-primary to-primary/80 rounded-full flex items-center justify-center shadow-lg shadow-primary/30">
                  <IconComponent className={`w-8 h-8 text-primary-foreground ${IconComponent === Loader2 ? 'animate-spin' : ''}`} />
                </div>
              </div>
              {/* Pulse rings */}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-20 h-20 rounded-full border-2 border-primary/30 animate-ping" style={{ animationDuration: '2s' }} />
              </div>
            </div>
            
            <div className="space-y-3">
              <h2 className="text-xl font-bold text-foreground">Processing Payment</h2>
              <p className="text-base text-primary font-semibold">
                {currentStepData?.text || "Please wait..."}
              </p>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Securely connecting you to PesaPal. Do not close or refresh this page.
              </p>
            </div>
            
            {/* Advanced Progress Steps */}
            <div className="space-y-4">
              {/* Step indicators */}
              <div className="flex justify-center gap-3">
                {steps.map((step, index) => {
                  const StepIcon = step.icon;
                  const isActive = index === currentStep;
                  const isComplete = index < currentStep;
                  return (
                    <div
                      key={index}
                      className={cn(
                        "w-10 h-10 rounded-full flex items-center justify-center transition-all duration-300",
                        isComplete 
                          ? "bg-primary text-primary-foreground" 
                          : isActive 
                            ? "bg-primary/20 text-primary ring-2 ring-primary ring-offset-2 ring-offset-background" 
                            : "bg-muted text-muted-foreground"
                      )}
                    >
                      {isComplete ? (
                        <CheckCircle className="w-5 h-5" />
                      ) : (
                        <StepIcon className={cn("w-5 h-5", isActive && StepIcon === Loader2 && "animate-spin")} />
                      )}
                    </div>
                  );
                })}
              </div>
              
              {/* Progress bar */}
              <div className="relative h-2 bg-muted rounded-full overflow-hidden">
                <div
                  className="absolute inset-y-0 left-0 bg-gradient-to-r from-primary to-primary/80 rounded-full transition-all duration-500 ease-out"
                  style={{ width: `${((currentStep + 1) / steps.length) * 100}%` }}
                />
                {/* Shimmer effect */}
                <div 
                  className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent animate-pulse"
                  style={{ animationDuration: '1.5s' }}
                />
              </div>
              
              <p className="text-xs text-muted-foreground">
                Step {currentStep + 1} of {steps.length}
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex flex-col items-center justify-center p-0 sm:p-4">
      <div className="bg-white dark:bg-zinc-900 w-full h-full sm:h-auto sm:max-h-[90vh] sm:max-w-2xl sm:rounded-2xl shadow-2xl flex flex-col overflow-hidden">
        {/* X.com style header */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-border/50 bg-white dark:bg-zinc-900 shrink-0">
          {onClose && (
            <button
              onClick={handleClose}
              className="p-2 -m-2 rounded-full hover:bg-muted transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          )}
          <h2 className="font-bold text-base text-foreground">Complete Payment</h2>
          <div className="w-9" />
        </div>

        {/* Scrollable content area */}
        <div className="flex-1 overflow-y-auto relative">
          {/* Loading skeleton */}
          {!iframeLoaded && (
            <div className="absolute inset-0 bg-white dark:bg-zinc-900 p-4 space-y-4">
              <div className="flex items-center gap-3 mb-6">
                <Skeleton className="w-12 h-12 rounded-full" />
                <div className="space-y-2 flex-1">
                  <Skeleton className="h-4 w-32" />
                  <Skeleton className="h-3 w-24" />
                </div>
              </div>
              <Skeleton className="h-12 w-full rounded-lg" />
              <Skeleton className="h-12 w-full rounded-lg" />
              <div className="pt-4 space-y-3">
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-4 w-1/2" />
              </div>
              <div className="pt-6">
                <Skeleton className="h-14 w-full rounded-xl" />
              </div>
              <div className="flex items-center justify-center pt-4 gap-2">
                <Loader2 className="w-4 h-4 animate-spin text-muted-foreground" />
                <span className="text-sm text-muted-foreground">Loading payment form...</span>
              </div>
            </div>
          )}
          <iframe
            ref={iframeRef}
            src={finalPaymentUrl || paymentUrl}
            className={`w-full h-full min-h-[500px] sm:min-h-[600px] border-0 ${!iframeLoaded ? 'invisible' : 'visible'}`}
            title="PesaPal Payment Checkout"
            onError={handleIframeError}
            onLoad={() => {
              console.log('PesaPal iframe loaded successfully');
              setIframeLoaded(true);
            }}
            sandbox="allow-same-origin allow-scripts allow-forms allow-popups allow-popups-to-escape-sandbox allow-top-navigation"
          />
        </div>

        {/* X.com style footer with assurance */}
        <div className="shrink-0 px-4 py-3 border-t border-border/50 bg-white dark:bg-zinc-900">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
              <Shield className="w-5 h-5 text-primary" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-foreground truncate">Secure Payment</p>
              <p className="text-xs text-muted-foreground">Your payment is encrypted and processed securely by PesaPal</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}