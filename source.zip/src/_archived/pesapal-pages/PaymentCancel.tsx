import { useNavigate } from 'react-router-dom';
import { XCircle, ArrowLeft, CreditCard } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';

export default function PaymentCancel() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <Card className="w-full max-w-sm border border-border">
        <CardContent className="p-6 text-center">
          <div className="w-12 h-12 bg-destructive/10 rounded-full flex items-center justify-center mx-auto mb-4">
            <XCircle className="w-6 h-6 text-destructive" />
          </div>
          
          <h1 className="text-lg font-bold text-foreground mb-2">
            Payment Cancelled
          </h1>
          
          <p className="text-muted-foreground text-sm mb-4">
            Your payment was cancelled. No charges were made to your account.
          </p>

          <div className="bg-primary/10 rounded-lg p-3 mb-4">
            <p className="text-xs text-primary">
              Need help? Contact our support team for assistance.
            </p>
          </div>

          <div className="space-y-2">
            <Button 
              onClick={() => navigate('/app/packages')} 
              className="w-full bg-primary hover:bg-primary/90 text-sm"
              size="sm"
            >
              <CreditCard className="w-4 h-4 mr-2" />
              Try Payment Again
            </Button>
            
            <Button 
              onClick={() => navigate('/app')} 
              variant="outline" 
              className="w-full text-sm"
              size="sm"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Dashboard
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
