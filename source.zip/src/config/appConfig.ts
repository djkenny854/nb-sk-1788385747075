
// App Configuration
// Toggle this to show/hide the landing page
// When false: Auth page is the entry point (App mode for Capacitor)
// When true: Landing page is shown first (Web mode)
export const APP_CONFIG = {
  showLandingPage: false,
} as const;
