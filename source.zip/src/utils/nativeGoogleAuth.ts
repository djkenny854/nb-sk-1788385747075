/**
 * Native Google Authentication for Capacitor with Supabase
 * 
 * This module handles native Google Sign-In on Android/iOS using
 * @capgo/capacitor-social-login and integrates with Supabase Auth.
 * 
 * IMPORTANT: You must install @capgo/capacitor-social-login locally:
 * npm install @capgo/capacitor-social-login
 */

import { Capacitor } from '@capacitor/core';
import { supabase } from '@/integrations/supabase/client';

// Your Web Client ID from Google Cloud Console (required for Android & Web)
// This MUST match the client ID configured in Supabase Auth
// TODO: Replace with your actual Web Client ID
export const GOOGLE_WEB_CLIENT_ID = 'YOUR_WEB_CLIENT_ID.apps.googleusercontent.com';

// iOS Client ID (only needed if you build for iOS)
// TODO: Replace with your actual iOS Client ID (if building for iOS)
export const GOOGLE_IOS_CLIENT_ID = 'YOUR_IOS_CLIENT_ID.apps.googleusercontent.com';

/**
 * Check if running in a native Capacitor environment
 */
export const isNativePlatform = (): boolean => {
  return Capacitor.isNativePlatform();
};

/**
 * Generate a URL-safe random nonce (64 hex characters)
 */
function getUrlSafeNonce(): string {
  const array = new Uint8Array(32);
  crypto.getRandomValues(array);
  return Array.from(array, (byte) => byte.toString(16).padStart(2, '0')).join('');
}

/**
 * Hash a string with SHA-256 (returns hex-encoded)
 */
async function sha256Hash(message: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(message);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
}

/**
 * Generate a nonce pair for Google Sign-In
 * - rawNonce: Goes to Supabase signInWithIdToken
 * - nonceDigest: Goes to Google Sign-In (SHA-256 hash)
 */
export async function generateNoncePair(): Promise<{ rawNonce: string; nonceDigest: string }> {
  const rawNonce = getUrlSafeNonce();
  const nonceDigest = await sha256Hash(rawNonce);
  return { rawNonce, nonceDigest };
}

/**
 * Decode a JWT token to read its payload
 */
export function decodeJWT(token: string): Record<string, any> {
  const parts = token.split('.');
  if (parts.length !== 3) {
    throw new Error('Invalid JWT format');
  }
  
  const payload = parts[1];
  // Handle URL-safe base64
  const base64 = payload.replace(/-/g, '+').replace(/_/g, '/');
  const padded = base64.padEnd(base64.length + (4 - (base64.length % 4)) % 4, '=');
  const decoded = atob(padded);
  return JSON.parse(decoded);
}

/**
 * Validate the JWT token before sending to Supabase
 */
export function validateJWTToken(
  idToken: string, 
  expectedNonceDigest: string,
  validClientIds: string[]
): { valid: boolean; error?: string } {
  try {
    const decodedToken = decodeJWT(idToken);
    
    // Check audience matches your Google Client IDs
    const audience = decodedToken.aud;
    if (!validClientIds.includes(audience)) {
      return { valid: false, error: `Invalid audience: ${audience}` };
    }
    
    // Check nonce matches (if present in token)
    const tokenNonce = decodedToken.nonce;
    if (tokenNonce && tokenNonce !== expectedNonceDigest) {
      return { valid: false, error: 'Nonce mismatch - cached token detected' };
    }
    
    return { valid: true };
  } catch (error: any) {
    return { valid: false, error: `JWT decode failed: ${error.message}` };
  }
}

interface NativeGoogleAuthResult {
  success: boolean;
  user?: any;
  session?: any;
  error?: string;
}

/**
 * Dynamically load the SocialLogin plugin
 * Returns null if the plugin is not installed
 * 
 * IMPORTANT: This uses a runtime-constructed string to prevent Vite from
 * statically analyzing the import. The plugin must be installed locally
 * in your project before building for production.
 */
async function getSocialLoginPlugin(): Promise<any | null> {
  try {
    // Construct the package name at runtime to prevent Vite static analysis
    const packageName = ['@capgo', 'capacitor-social-login'].join('/');
    // Use Function constructor to create a dynamic import that Vite can't analyze
    const dynamicImport = new Function('packageName', 'return import(packageName)');
    const module = await dynamicImport(packageName);
    return module.SocialLogin;
  } catch (error) {
    console.warn('[NativeGoogleAuth] @capgo/capacitor-social-login not installed. Install it locally with: npm install @capgo/capacitor-social-login@6.5.1');
    return null;
  }
}

/**
 * Perform native Google Sign-In and authenticate with Supabase
 * 
 * This function:
 * 1. Generates a secure nonce pair
 * 2. Triggers native Google Sign-In dialog
 * 3. Validates the returned JWT
 * 4. Signs in to Supabase with the ID token
 * 
 * @param webClientId - Your Google Web Client ID
 * @param iOSClientId - Your Google iOS Client ID (optional, for iOS builds)
 */
export async function authenticateWithNativeGoogle(
  webClientId: string = GOOGLE_WEB_CLIENT_ID,
  iOSClientId: string = GOOGLE_IOS_CLIENT_ID
): Promise<NativeGoogleAuthResult> {
  // Dynamically import to avoid issues on web and when not installed
  const SocialLogin = await getSocialLoginPlugin();
  
  if (!SocialLogin) {
    return {
      success: false,
      error: 'Social Login plugin not installed. Please install @capgo/capacitor-social-login'
    };
  }
  
  // Build list of valid client IDs for validation
  const validClientIds = [webClientId];
  if (iOSClientId && iOSClientId !== 'YOUR_IOS_CLIENT_ID.apps.googleusercontent.com') {
    validClientIds.push(iOSClientId);
  }
  
  // Generate nonce pair
  const { rawNonce, nonceDigest } = await generateNoncePair();
  console.log('[NativeGoogleAuth] Generated nonce pair');
  
  // Attempt authentication (with one automatic retry on failure)
  for (let attempt = 1; attempt <= 2; attempt++) {
    try {
      // Initialize the plugin
      await SocialLogin.initialize({
        google: {
          webClientId,
          ...(Capacitor.getPlatform() === 'ios' && iOSClientId 
            ? { iOSClientId } 
            : {}),
        },
      });
      console.log(`[NativeGoogleAuth] Attempt ${attempt}: Plugin initialized`);
      
      // Perform Google Sign-In with nonce
      const response = await SocialLogin.login({
        provider: 'google',
        options: {
          scopes: ['email', 'profile'],
          nonce: nonceDigest, // SHA-256 hashed nonce goes to Google
        },
      });
      
      console.log('[NativeGoogleAuth] Google login response received');
      
      // Check if we got an ID token
      if (!response.result?.idToken) {
        throw new Error('No ID token received from Google');
      }
      
      const idToken = response.result.idToken;
      
      // Validate JWT before sending to Supabase
      const validation = validateJWTToken(idToken, nonceDigest, validClientIds);
      
      if (!validation.valid) {
        console.warn(`[NativeGoogleAuth] JWT validation failed: ${validation.error}`);
        
        // If this is the first attempt, logout and retry
        if (attempt === 1) {
          console.log('[NativeGoogleAuth] Logging out and retrying...');
          await SocialLogin.logout({ provider: 'google' });
          continue; // Retry
        }
        
        return { 
          success: false, 
          error: validation.error 
        };
      }
      
      console.log('[NativeGoogleAuth] JWT validated, signing in to Supabase...');
      
      // Sign in to Supabase with the ID token
      const { data, error } = await supabase.auth.signInWithIdToken({
        provider: 'google',
        token: idToken,
        nonce: rawNonce, // Raw (unhashed) nonce goes to Supabase
      });
      
      if (error) {
        console.error('[NativeGoogleAuth] Supabase sign-in error:', error);
        return { 
          success: false, 
          error: error.message 
        };
      }
      
      console.log('[NativeGoogleAuth] Successfully signed in!');
      return { 
        success: true, 
        user: data.user,
        session: data.session
      };
      
    } catch (error: any) {
      console.error(`[NativeGoogleAuth] Attempt ${attempt} error:`, error);
      
      // If this is the first attempt, logout and retry
      if (attempt === 1) {
        try {
          await SocialLogin.logout({ provider: 'google' });
        } catch (logoutError) {
          // Ignore logout errors
        }
        continue; // Retry
      }
      
      return { 
        success: false, 
        error: error.message || 'Google Sign-In failed' 
      };
    }
  }
  
  return { 
    success: false, 
    error: 'Authentication failed after retries' 
  };
}

/**
 * Sign out from native Google
 */
export async function signOutNativeGoogle(): Promise<void> {
  if (!isNativePlatform()) return;
  
  try {
    const SocialLogin = await getSocialLoginPlugin();
    if (SocialLogin) {
      await SocialLogin.logout({ provider: 'google' });
      console.log('[NativeGoogleAuth] Signed out from Google');
    }
  } catch (error) {
    console.warn('[NativeGoogleAuth] Logout error:', error);
  }
}
