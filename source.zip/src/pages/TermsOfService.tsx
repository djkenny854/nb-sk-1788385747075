import { FileText, Calendar, Shield, AlertTriangle } from 'lucide-react';

export default function TermsOfService() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-gradient-to-r from-zinc-800 to-zinc-900 dark:from-zinc-900 dark:to-black text-white py-16">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <FileText className="w-16 h-16 mx-auto mb-6" />
          <h1 className="text-4xl font-bold mb-4">Terms of Service</h1>
          <p className="text-xl text-zinc-300">
            Please read these terms carefully before using our services
          </p>
          <div className="flex items-center justify-center gap-2 mt-4 text-zinc-400">
            <Calendar className="w-4 h-4" />
            <span>Last updated: January 2024</span>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-6 py-16">
        <div className="bg-card rounded-2xl shadow-lg border border-border p-8 space-y-8">
          
          {/* Introduction */}
          <section>
            <h2 className="text-2xl font-bold text-foreground mb-4 flex items-center gap-2">
              <Shield className="w-6 h-6 text-primary" />
              1. Introduction
            </h2>
            <p className="text-muted-foreground leading-relaxed">
              Welcome to Kalaso Football Predictions. These Terms of Service ("Terms") govern your use of our website, 
              mobile application, and betting prediction services. By accessing or using our services, 
              you agree to be bound by these Terms.
            </p>
          </section>

          {/* Services */}
          <section>
            <h2 className="text-2xl font-bold text-foreground mb-4">2. Our Services</h2>
            <div className="space-y-3 text-muted-foreground">
              <p>Kalaso Football Predictions provides:</p>
              <ul className="list-disc list-inside space-y-2 ml-4">
                <li>Football betting predictions and analysis</li>
                <li>Premium subscription packages with expert tips</li>
                <li>Free daily predictions for registered users</li>
                <li>Customer support and betting guidance</li>
              </ul>
            </div>
          </section>

          {/* User Responsibilities */}
          <section>
            <h2 className="text-2xl font-bold text-foreground mb-4">3. User Responsibilities</h2>
            <div className="space-y-3 text-muted-foreground">
              <p>As a user of our services, you agree to:</p>
              <ul className="list-disc list-inside space-y-2 ml-4">
                <li>Provide accurate and complete registration information</li>
                <li>Maintain the security of your account credentials</li>
                <li>Use our services only for lawful purposes</li>
                <li>Not share your account with others</li>
                <li>Bet responsibly and within your means</li>
                <li>Comply with all applicable laws and regulations</li>
              </ul>
            </div>
          </section>

          {/* Payment Terms */}
          <section>
            <h2 className="text-2xl font-bold text-foreground mb-4">4. Payment and Subscriptions</h2>
            <div className="space-y-3 text-muted-foreground">
              <ul className="list-disc list-inside space-y-2">
                <li>All subscription fees are charged in Ugandan Shillings (UGX)</li>
                <li>Payments are processed securely through PesaPal</li>
                <li>Subscriptions are non-refundable once activated</li>
                <li>You may cancel your subscription at any time</li>
                <li>We reserve the right to change pricing with 30 days notice</li>
              </ul>
            </div>
          </section>

          {/* Disclaimer */}
          <section className="bg-primary/10 dark:bg-primary/5 border border-primary/20 rounded-xl p-6">
            <h2 className="text-2xl font-bold text-foreground mb-4 flex items-center gap-2">
              <AlertTriangle className="w-6 h-6 text-primary" />
              5. Important Disclaimer
            </h2>
            <div className="space-y-3 text-muted-foreground">
              <p className="font-semibold">
                Please read this section carefully as it contains important information about the nature of our services.
              </p>
              <ul className="list-disc list-inside space-y-2">
                <li>Our predictions are based on analysis and research, but betting always involves risk</li>
                <li>We cannot guarantee winning outcomes for any predictions</li>
                <li>Past performance does not guarantee future results</li>
                <li>You are solely responsible for your betting decisions</li>
                <li>We strongly encourage responsible gambling practices</li>
                <li>Never bet more than you can afford to lose</li>
              </ul>
            </div>
          </section>

          {/* Account Termination */}
          <section>
            <h2 className="text-2xl font-bold text-foreground mb-4">6. Account Termination</h2>
            <div className="space-y-3 text-muted-foreground">
              <p>We reserve the right to terminate or suspend accounts that:</p>
              <ul className="list-disc list-inside space-y-2 ml-4">
                <li>Violate these Terms of Service</li>
                <li>Engage in fraudulent activities</li>
                <li>Share account credentials with others</li>
                <li>Use our services for illegal purposes</li>
              </ul>
            </div>
          </section>

          {/* Privacy */}
          <section>
            <h2 className="text-2xl font-bold text-foreground mb-4">7. Privacy and Data Protection</h2>
            <p className="text-muted-foreground leading-relaxed">
              We are committed to protecting your privacy. We collect and use your personal information 
              in accordance with our Privacy Policy. By using our services, you consent to the collection 
              and use of your information as described in our Privacy Policy.
            </p>
          </section>

          {/* Limitation of Liability */}
          <section>
            <h2 className="text-2xl font-bold text-foreground mb-4">8. Limitation of Liability</h2>
            <p className="text-muted-foreground leading-relaxed">
              Kalaso Football Predictions shall not be liable for any direct, indirect, incidental, special, or 
              consequential damages arising from your use of our services, including but not limited 
              to financial losses from betting activities.
            </p>
          </section>

          {/* Governing Law */}
          <section>
            <h2 className="text-2xl font-bold text-foreground mb-4">9. Governing Law</h2>
            <p className="text-muted-foreground leading-relaxed">
              These Terms are governed by the laws of Uganda. Any disputes arising from these Terms 
              or your use of our services shall be subject to the exclusive jurisdiction of the 
              courts of Uganda.
            </p>
          </section>

          {/* Changes to Terms */}
          <section>
            <h2 className="text-2xl font-bold text-foreground mb-4">10. Changes to Terms</h2>
            <p className="text-muted-foreground leading-relaxed">
              We reserve the right to modify these Terms at any time. We will notify users of any 
              material changes via email or through our platform. Continued use of our services 
              after changes constitutes acceptance of the new Terms.
            </p>
          </section>

          {/* Contact Information */}
          <section className="bg-primary/10 dark:bg-primary/5 border border-primary/20 rounded-xl p-6">
            <h2 className="text-2xl font-bold text-foreground mb-4">11. Contact Us</h2>
            <p className="text-muted-foreground mb-4">
              If you have any questions about these Terms of Service, please contact us:
            </p>
            <div className="space-y-2 text-muted-foreground">
              <p>📧 Email: info@sksurewins.com</p>
              <p>📞 Phone: +256 XXX XXX XXX</p>
              <p>📍 Address: Kampala, Uganda</p>
            </div>
          </section>
        </div>

        {/* Agreement Statement */}
        <div className="mt-8 text-center">
          <div className="bg-muted/50 rounded-2xl p-6 border border-border">
            <p className="text-muted-foreground mb-4">
              By using Kalaso Football Predictions services, you acknowledge that you have read, understood, 
              and agree to be bound by these Terms of Service.
            </p>
            <p className="text-sm text-muted-foreground">
              © 2024 Kalaso Football Predictions. All rights reserved.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
