import { FreeTipsSection } from '@/components/FreeTipsSection';
import { ResponsiveLayout } from '@/components/ResponsiveLayout';

export default function FreeTips() {
  return (
    <ResponsiveLayout>
      <div className="space-y-6">
        <div className="text-center">
          <h1 className="text-3xl font-bold text-foreground mb-2">Free Tips</h1>
          <p className="text-muted-foreground">Get our latest free betting tips and predictions</p>
        </div>
        <FreeTipsSection />
      </div>
    </ResponsiveLayout>
  );
}
