import { useState } from 'react'
import { PageTransition } from '@/components/PageTransition'
import { useNotifications } from '@/hooks/useNotifications'
import { Bell, Check, CheckCheck, Settings, Trash2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { cn } from '@/lib/utils'
import { formatDistanceToNow } from 'date-fns'

export default function Notifications() {
  const { notifications, loading, markAsRead, markAllAsRead } = useNotifications()
  const [filter, setFilter] = useState<'all' | 'unread'>('all')

  const filteredNotifications = notifications.filter(n => 
    filter === 'all' ? true : !n.is_read
  )

  const unreadCount = notifications.filter(n => !n.is_read).length

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'payment':
        return '💰'
      case 'subscription':
        return '⭐'
      case 'tip':
        return '🎯'
      case 'system':
        return '🔔'
      default:
        return '📬'
    }
  }

  if (loading) {
    return (
      <PageTransition>
        <div className="min-h-screen">
          <div className="sticky top-0 z-10 backdrop-blur-md bg-background/80 border-b border-border px-4 py-3">
            <h1 className="text-xl font-bold">Notifications</h1>
          </div>
          <div className="divide-y divide-border">
            {[1, 2, 3, 4, 5].map((i) => (
              <div key={i} className="p-4 animate-pulse">
                <div className="flex gap-3">
                  <div className="w-10 h-10 bg-muted rounded-full" />
                  <div className="flex-1 space-y-2">
                    <div className="h-4 bg-muted rounded w-3/4" />
                    <div className="h-3 bg-muted rounded w-1/2" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </PageTransition>
    )
  }

  return (
    <PageTransition>
      <div className="min-h-screen bg-background">
        {/* Sticky Header */}
        <div className="sticky top-0 z-10 backdrop-blur-md bg-background/80 border-b border-border">
          <div className="px-4 py-3 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <h1 className="text-xl font-bold">Notifications</h1>
              {unreadCount > 0 && (
                <Badge variant="default" className="bg-primary text-primary-foreground">
                  {unreadCount}
                </Badge>
              )}
            </div>
            <Button variant="ghost" size="icon" className="rounded-full">
              <Settings className="w-5 h-5" />
            </Button>
          </div>

          {/* Filter Tabs */}
          <div className="flex border-b border-border">
            <button
              onClick={() => setFilter('all')}
              className={cn(
                "flex-1 py-4 text-center relative font-medium transition-colors hover:bg-muted/50",
                filter === 'all' ? "text-foreground" : "text-muted-foreground"
              )}
            >
              All
              {filter === 'all' && (
                <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-16 h-1 bg-primary rounded-full" />
              )}
            </button>
            <button
              onClick={() => setFilter('unread')}
              className={cn(
                "flex-1 py-4 text-center relative font-medium transition-colors hover:bg-muted/50",
                filter === 'unread' ? "text-foreground" : "text-muted-foreground"
              )}
            >
              Unread
              {filter === 'unread' && (
                <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-16 h-1 bg-primary rounded-full" />
              )}
            </button>
          </div>
        </div>

        {/* Mark All as Read Button */}
        {unreadCount > 0 && (
          <div className="px-4 py-3 border-b border-border">
            <Button
              variant="ghost"
              size="sm"
              onClick={markAllAsRead}
              className="text-primary hover:text-primary/90 hover:bg-primary/10"
            >
              <CheckCheck className="w-4 h-4 mr-2" />
              Mark all as read
            </Button>
          </div>
        )}

        {/* Notifications List */}
        {filteredNotifications.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 px-4 text-center">
            <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mb-4">
              <Bell className="w-8 h-8 text-muted-foreground" />
            </div>
            <h3 className="text-xl font-bold mb-2">
              {filter === 'unread' ? 'No unread notifications' : 'No notifications yet'}
            </h3>
            <p className="text-muted-foreground max-w-xs">
              {filter === 'unread' 
                ? "You're all caught up! Check back later for new updates."
                : "When you get notifications, they'll show up here."
              }
            </p>
          </div>
        ) : (
          <div className="divide-y divide-border">
            {filteredNotifications.map((notification) => (
              <div
                key={notification.id}
                className={cn(
                  "px-4 py-4 hover:bg-muted/50 transition-colors cursor-pointer",
                  !notification.is_read && "bg-primary/5"
                )}
                onClick={() => !notification.is_read && markAsRead(notification.id)}
              >
                <div className="flex gap-3">
                  <div className={cn(
                    "w-10 h-10 rounded-full flex items-center justify-center text-lg flex-shrink-0",
                    !notification.is_read ? "bg-primary/10" : "bg-muted"
                  )}>
                    {getNotificationIcon(notification.type)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <h3 className={cn(
                        "text-[15px] leading-snug",
                        !notification.is_read && "font-semibold"
                      )}>
                        {notification.title}
                      </h3>
                      {!notification.is_read && (
                        <div className="w-2 h-2 rounded-full bg-primary flex-shrink-0 mt-1.5" />
                      )}
                    </div>
                    <p className="text-muted-foreground text-[15px] mt-0.5 line-clamp-2">
                      {notification.message}
                    </p>
                    <p className="text-muted-foreground text-[13px] mt-1">
                      {formatDistanceToNow(new Date(notification.created_at), { addSuffix: true })}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </PageTransition>
  )
}
