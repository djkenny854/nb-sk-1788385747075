import { useState } from 'react';
import { ChevronDown, ChevronUp, HelpCircle, MessageSquare, Phone, Mail } from 'lucide-react';
import { Link } from 'react-router-dom';

const faqs = [
  {
    id: 1,
    question: "How do I subscribe to a package?",
    answer: "To subscribe to a package, simply navigate to the Packages tab, choose your preferred plan, and click 'Subscribe'. You'll be redirected to our secure payment gateway (PesaPal) to complete the transaction."
  },
  {
    id: 2,
    question: "What payment methods do you accept?",
    answer: "We accept all major payment methods through PesaPal including Mobile Money (MTN & Airtel), Visa, Mastercard, and bank transfers."
  },
  {
    id: 3,
    question: "How soon will I receive tips after subscribing?",
    answer: "Tips are delivered daily directly to your account. You'll receive notifications when new tips are available, typically in the morning before match days."
  },
  {
    id: 4,
    question: "What is your success rate?",
    answer: "Our expert analysts maintain an impressive 85%+ success rate across all our premium packages. We provide detailed statistics and track records for transparency."
  },
  {
    id: 5,
    question: "Can I cancel my subscription?",
    answer: "Yes, you can cancel your subscription at any time. However, we don't offer refunds for unused periods as our tips are delivered in real-time."
  },
  {
    id: 6,
    question: "How many devices can I use with one account?",
    answer: "Each account can be used on up to 2 devices simultaneously. If you need access on more devices, please contact our support team."
  },
  {
    id: 7,
    question: "Do you offer free tips?",
    answer: "Yes! We provide daily free tips to give you a taste of our prediction quality. Check the Free Tips section to see our latest predictions."
  },
  {
    id: 8,
    question: "How do I update my phone number or email?",
    answer: "You can update your profile information by going to the Profile tab and clicking 'Edit'. Make sure to use a valid Ugandan phone number (+256XXXXXXXXX)."
  }
];

export default function HelpCenter() {
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  const toggleFaq = (id: number) => {
    setOpenFaq(openFaq === id ? null : id);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-gradient-to-r from-primary/20 to-primary/10 border-b border-border py-12">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <HelpCircle className="w-12 h-12 mx-auto mb-4 text-primary" />
          <h1 className="text-2xl font-bold text-foreground mb-2">Help Center</h1>
          <p className="text-sm text-muted-foreground">
            Find answers to frequently asked questions
          </p>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-8">
        {/* Quick Links */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <Link to="/contact" className="bg-card rounded-xl p-4 border border-border hover:border-primary/50 transition-all text-center group">
            <MessageSquare className="w-8 h-8 text-primary mx-auto mb-2 group-hover:scale-110 transition-transform" />
            <h3 className="font-semibold text-sm text-foreground mb-1">Contact Support</h3>
            <p className="text-muted-foreground text-xs">Get personalized help</p>
          </Link>

          <div className="bg-card rounded-xl p-4 border border-border text-center">
            <Phone className="w-8 h-8 text-green-500 mx-auto mb-2" />
            <h3 className="font-semibold text-sm text-foreground mb-1">Call Us</h3>
            <p className="text-muted-foreground text-xs">+256 XXX XXX XXX</p>
          </div>

          <div className="bg-card rounded-xl p-4 border border-border text-center">
            <Mail className="w-8 h-8 text-primary mx-auto mb-2" />
            <h3 className="font-semibold text-sm text-foreground mb-1">Email Us</h3>
            <p className="text-muted-foreground text-xs">info@sksurewins.com</p>
          </div>
        </div>

        {/* FAQ Section */}
        <div className="bg-card rounded-xl border border-border p-4 sm:p-6">
          <h2 className="text-lg font-bold text-center text-foreground mb-6">Frequently Asked Questions</h2>
          
          <div className="space-y-3">
            {faqs.map((faq) => (
              <div key={faq.id} className="border border-border rounded-lg overflow-hidden">
                <button
                  onClick={() => toggleFaq(faq.id)}
                  className="w-full px-4 py-3 text-left flex justify-between items-center hover:bg-muted/50 transition-colors"
                >
                  <span className="font-medium text-sm text-foreground pr-2">{faq.question}</span>
                  {openFaq === faq.id ? (
                    <ChevronUp className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                  ) : (
                    <ChevronDown className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                  )}
                </button>
                
                {openFaq === faq.id && (
                  <div className="px-4 pb-3 border-t border-border">
                    <p className="text-muted-foreground pt-3 text-sm leading-relaxed">{faq.answer}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Additional Help */}
        <div className="mt-8 text-center">
          <div className="bg-muted/30 rounded-xl p-6 border border-border">
            <h3 className="text-base font-bold text-foreground mb-2">Still Need Help?</h3>
            <p className="text-muted-foreground text-sm mb-4">
              Our support team is here to help you 24/7.
            </p>
            <Link to="/contact">
              <button className="bg-primary hover:bg-primary/90 text-primary-foreground px-6 py-2 rounded-full font-semibold text-sm transition-colors">
                Contact Support
              </button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
