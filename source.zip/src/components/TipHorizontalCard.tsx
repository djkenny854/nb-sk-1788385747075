import React, { useState } from 'react';
import { Badge } from '@/components/ui/badge';
import { Download, MoreHorizontal, ExternalLink } from 'lucide-react';
import { cn } from '@/lib/utils';
import { XImageModal } from './XImageModal';
import { toast } from 'sonner';
import betikaLogo from '@/assets/betika-logo.png';
import betpawaLogo from '@/assets/betpawa-logo.png';

interface Match {
  id: string;
  match_name: string;
  match_time: string;
  prediction: string;
  odds: string;
}

interface TipHorizontalCardProps {
  ticket: {
    id: string;
    ticket_name: string;
    status: string;
    comments?: string;
    betika_link?: string;
    betpawa_link?: string;
    created_at: string;
    image_url?: string;
    matches: Match[];
    package_name?: string;
    match_count?: number;
  };
  getStatusColor: (status: string) => string;
  getStatusIcon: (status: string) => string;
  isFree?: boolean;
}

export function TipHorizontalCard({ ticket, getStatusColor, getStatusIcon, isFree = false }: TipHorizontalCardProps) {
  const [selectedImage, setSelectedImage] = useState<{ url: string; name: string } | null>(null);

  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);
    
    if (diffMins < 60) return `${diffMins}m`;
    if (diffHours < 24) return `${diffHours}h`;
    if (diffDays < 7) return `${diffDays}d`;
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };

  const handleDownload = async () => {
    if (ticket.image_url) {
      try {
        const response = await fetch(ticket.image_url);
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${ticket.ticket_name.replace(/\s+/g, '_')}.jpg`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
        toast.success('Image downloaded!');
      } catch {
        toast.error('Failed to download image');
      }
    } else {
      toast.info('No image available to download');
    }
  };

  const getStatusBadgeClass = (status: string) => {
    switch (status.toLowerCase()) {
      case 'won': return 'bg-green-500/20 text-green-400 border-green-500/30';
      case 'lost': return 'bg-red-500/20 text-red-400 border-red-500/30';
      default: return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
    }
  };

  const [showMenu, setShowMenu] = useState(false);

  return (
    <>
      <article className="border-b border-border hover:bg-muted/30 transition-colors cursor-pointer">
        <div className="px-4 py-3">
          <div className="flex gap-3">
            {/* Avatar */}
            <div className="flex-shrink-0">
              <div className={cn(
                "w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-sm",
                isFree ? "bg-gradient-to-br from-blue-500 to-blue-600" : "bg-gradient-to-br from-primary to-primary/80"
              )}>
                {ticket.ticket_name.charAt(0).toUpperCase()}
              </div>
            </div>

            {/* Content */}
            <div className="flex-1 min-w-0">
              {/* Header - Restructured to prevent overlap */}
              <div className="flex items-start justify-between gap-2 mb-0.5">
                <div className="flex items-center gap-1 min-w-0 flex-1 flex-wrap">
                  <span className="font-bold text-[14px] text-foreground truncate max-w-[120px] sm:max-w-none">
                    {ticket.ticket_name}
                  </span>
                  <svg viewBox="0 0 22 22" className="w-4 h-4 text-primary fill-current flex-shrink-0">
                    <path d="M20.396 11c-.018-.646-.215-1.275-.57-1.816-.354-.54-.852-.972-1.438-1.246.223-.607.27-1.264.14-1.897-.131-.634-.437-1.218-.882-1.687-.47-.445-1.053-.75-1.687-.882-.633-.13-1.29-.083-1.897.14-.273-.587-.704-1.086-1.245-1.44S11.647 1.62 11 1.604c-.646.017-1.273.213-1.813.568s-.969.854-1.24 1.44c-.608-.223-1.267-.272-1.902-.14-.635.13-1.22.436-1.69.882-.445.47-.749 1.055-.878 1.688-.13.633-.08 1.29.144 1.896-.587.274-1.087.705-1.443 1.245-.356.54-.555 1.17-.574 1.817.02.647.218 1.276.574 1.817.356.54.856.972 1.443 1.245-.224.606-.274 1.263-.144 1.896.13.634.433 1.218.877 1.688.47.443 1.054.747 1.687.878.633.132 1.29.084 1.897-.136.274.586.705 1.084 1.246 1.439.54.354 1.17.551 1.816.569.647-.016 1.276-.213 1.817-.567s.972-.854 1.245-1.44c.604.239 1.266.296 1.903.164.636-.132 1.22-.447 1.68-.907.46-.46.776-1.044.908-1.681s.075-1.299-.165-1.903c.586-.274 1.084-.705 1.439-1.246.354-.54.551-1.17.569-1.816zM9.662 14.85l-3.429-3.428 1.293-1.302 2.072 2.072 4.4-4.794 1.347 1.246z" />
                  </svg>
                  <span className="text-muted-foreground text-[13px] hidden sm:inline">·</span>
                  <span className="text-muted-foreground text-[12px] sm:text-[13px]">{formatTimeAgo(ticket.created_at)}</span>
                </div>
                <div className="flex items-center gap-1 flex-shrink-0">
                  <Badge className={cn("text-[10px] px-1.5 py-0 h-5 border whitespace-nowrap", getStatusBadgeClass(ticket.status))}>
                    {getStatusIcon(ticket.status)} {ticket.status}
                  </Badge>
                  <div className="relative">
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        setShowMenu(!showMenu);
                      }}
                      className="p-1.5 hover:bg-primary/10 rounded-full transition-colors"
                    >
                      <MoreHorizontal className="w-4 h-4 text-muted-foreground" />
                    </button>
                    {/* Dropdown menu */}
                    {showMenu && (
                      <>
                        <div 
                          className="fixed inset-0 z-40"
                          onClick={(e) => {
                            e.stopPropagation();
                            setShowMenu(false);
                          }}
                        />
                        <div className="absolute right-0 top-8 z-50 bg-background border border-border rounded-lg shadow-lg py-1 min-w-[140px]">
                          {ticket.image_url && (
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                handleDownload();
                                setShowMenu(false);
                              }}
                              className="w-full px-3 py-2 text-left text-[13px] hover:bg-muted transition-colors flex items-center gap-2"
                            >
                              <Download className="w-4 h-4" />
                              Download Image
                            </button>
                          )}
                          {ticket.betpawa_link && (
                            <a
                              href={ticket.betpawa_link}
                              target="_blank"
                              rel="noopener noreferrer"
                              onClick={(e) => {
                                e.stopPropagation();
                                setShowMenu(false);
                              }}
                              className="w-full px-3 py-2 text-left text-[13px] hover:bg-muted transition-colors flex items-center gap-2"
                            >
                              <ExternalLink className="w-4 h-4" />
                              Open in Betpawa
                            </a>
                          )}
                          {ticket.betika_link && (
                            <a
                              href={ticket.betika_link}
                              target="_blank"
                              rel="noopener noreferrer"
                              onClick={(e) => {
                                e.stopPropagation();
                                setShowMenu(false);
                              }}
                              className="w-full px-3 py-2 text-left text-[13px] hover:bg-muted transition-colors flex items-center gap-2"
                            >
                              <ExternalLink className="w-4 h-4" />
                              Open in Betika
                            </a>
                          )}
                          {!ticket.image_url && !ticket.betpawa_link && !ticket.betika_link && (
                            <div className="px-3 py-2 text-[13px] text-muted-foreground">
                              No actions available
                            </div>
                          )}
                        </div>
                      </>
                    )}
                  </div>
                </div>
              </div>

              {/* Subheader with match count */}
              <div className="text-muted-foreground text-[13px] mb-2 flex items-center gap-1">
                <span>@{isFree ? 'freetips' : ticket.package_name?.toLowerCase().replace(/\s/g, '')}</span>
                <span>·</span>
                <span className="inline-flex items-center gap-1 bg-primary/10 text-primary px-1.5 py-0.5 rounded-full text-[11px] font-medium">
                  {ticket.match_count || ticket.matches.length} {(ticket.match_count || ticket.matches.length) === 1 ? 'match' : 'matches'}
                </span>
              </div>

              {/* Main content */}
              <div className="text-[15px] text-foreground leading-5 mb-3">
                {ticket.comments || `Today's ${isFree ? 'free' : 'premium'} prediction ticket with ${ticket.matches.length} carefully selected matches. 🎯`}
              </div>

              {/* Matches preview */}
              {ticket.matches.length > 0 && (
                <div className="bg-muted/50 rounded-xl border border-border overflow-hidden mb-3">
                  {ticket.matches.slice(0, 3).map((match, index) => (
                    <div 
                      key={match.id} 
                      className={cn(
                        "px-3 py-2 flex items-center justify-between",
                        index !== Math.min(ticket.matches.length - 1, 2) && "border-b border-border"
                      )}
                    >
                      <div className="flex-1 min-w-0">
                        <div className="text-[14px] text-foreground font-medium truncate">{match.match_name}</div>
                        <div className="text-[12px] text-muted-foreground">{match.prediction}</div>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-[12px] text-muted-foreground">
                          {new Date(match.match_time).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}
                        </span>
                        <Badge variant="secondary" className="text-[11px] bg-primary/10 text-primary">
                          @{match.odds}
                        </Badge>
                      </div>
                    </div>
                  ))}
                  {ticket.matches.length > 3 && (
                    <div className="px-3 py-2 text-[13px] text-primary hover:bg-muted/70 transition-colors">
                      +{ticket.matches.length - 3} more matches
                    </div>
                  )}
                </div>
              )}

              {/* Image preview */}
              {ticket.image_url && (
                <div 
                  className="rounded-2xl overflow-hidden border border-border mb-3 cursor-pointer hover:opacity-90 transition-opacity"
                  onClick={() => setSelectedImage({ url: ticket.image_url!, name: ticket.ticket_name })}
                >
                  <img 
                    src={ticket.image_url} 
                    alt={ticket.ticket_name}
                    className="w-full max-h-[280px] object-cover"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      target.style.display = 'none';
                    }}
                  />
                </div>
              )}

              {/* Actions */}
              <div className="flex items-center gap-1 flex-wrap">
                {/* Download - only show if image exists */}
                {ticket.image_url && (
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      handleDownload();
                    }}
                    className="flex items-center gap-1 px-2 py-1 hover:bg-muted rounded-full group transition-colors"
                  >
                    <Download className="w-3.5 h-3.5 text-muted-foreground group-hover:text-primary" />
                    <span className="text-xs text-muted-foreground group-hover:text-primary">Download</span>
                  </button>
                )}

                {/* Betpawa link with logo */}
                {ticket.betpawa_link && (
                  <a
                    href={ticket.betpawa_link}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={(e) => e.stopPropagation()}
                    className="flex items-center h-8 px-2 rounded-lg bg-muted hover:bg-muted/80 border border-border transition-colors"
                    title="Open in Betpawa"
                  >
                    <img 
                      src={betpawaLogo} 
                      alt="Betpawa" 
                      className="h-5 w-auto object-contain"
                    />
                  </a>
                )}

                {/* Betika link with logo */}
                {ticket.betika_link && (
                  <a
                    href={ticket.betika_link}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={(e) => e.stopPropagation()}
                    className="flex items-center h-8 px-2 rounded-lg bg-muted hover:bg-muted/80 border border-border transition-colors"
                    title="Open in Betika"
                  >
                    <img 
                      src={betikaLogo} 
                      alt="Betika" 
                      className="h-5 w-auto object-contain"
                    />
                  </a>
                )}
              </div>
            </div>
          </div>
        </div>
      </article>

      {/* X-style Image Modal */}
      {selectedImage && (
        <XImageModal
          isOpen={!!selectedImage}
          onClose={() => setSelectedImage(null)}
          imageUrl={selectedImage.url}
          ticketName={selectedImage.name}
        />
      )}
    </>
  );
}
