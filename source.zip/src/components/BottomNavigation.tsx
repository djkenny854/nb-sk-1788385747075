
import { Home, Target, Package, User } from 'lucide-react';
import { cn } from '@/lib/utils';

interface BottomNavigationProps {
  activeTab?: string;
  onTabChange?: (tab: string) => void;
}

export function BottomNavigation({ activeTab, onTabChange }: BottomNavigationProps) {
  const navItems = [
    { 
      icon: Home, 
      label: 'Home', 
      tab: 'home',
      gradient: 'from-blue-500 to-blue-600'
    },
    { 
      icon: Target, 
      label: 'Tips', 
      tab: 'tips',
      gradient: 'from-green-500 to-green-600'
    },
    { 
      icon: Package, 
      label: 'Packages', 
      tab: 'packages',
      gradient: 'from-purple-500 to-purple-600'
    },
    { 
      icon: User, 
      label: 'Profile', 
      tab: 'profile',
      gradient: 'from-orange-500 to-orange-600'
    },
  ];

  const handleTabChange = (tab: string) => {
    if (onTabChange) {
      onTabChange(tab);
    }
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-xl border-t border-gray-200 shadow-2xl z-50">
      <div className="flex items-center justify-around px-2 py-3 safe-area-inset-bottom max-w-md mx-auto">
        {navItems.map((item) => {
          const isActive = activeTab === item.tab;
          
          return (
            <button
              key={item.label}
              onClick={() => handleTabChange(item.tab)}
              className={cn(
                "flex flex-col items-center justify-center p-3 rounded-2xl transition-all duration-300 min-w-0 flex-1 group relative touch-manipulation transform-gpu",
                isActive 
                  ? "text-white scale-110" 
                  : "text-gray-500 hover:text-gray-700 hover:scale-105"
              )}
            >
              {/* Active background gradient */}
              {isActive && (
                <div className={cn(
                  "absolute inset-0 rounded-2xl bg-gradient-to-r shadow-lg",
                  item.gradient
                )} />
              )}
              
              {/* Icon container */}
              <div className={cn(
                "relative z-10 p-1 rounded-full transition-all duration-300",
                isActive 
                  ? "bg-white/20" 
                  : "group-hover:bg-gray-100"
              )}>
                <item.icon className={cn(
                  "w-5 h-5 transition-all duration-300", 
                  isActive 
                    ? "text-white drop-shadow-sm" 
                    : "group-hover:text-gray-700"
                )} />
              </div>
              
              {/* Label */}
              <span className={cn(
                "relative z-10 text-xs font-medium transition-all duration-300 mt-1",
                isActive 
                  ? "text-white font-semibold" 
                  : "group-hover:font-medium group-hover:text-gray-700"
              )}>
                {item.label}
              </span>

              {/* Active indicator dot */}
              {isActive && (
                <div className="absolute -top-1 left-1/2 transform -translate-x-1/2 w-1 h-1 bg-white rounded-full animate-pulse" />
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}
