
import { ReactNode } from 'react';
import { BottomNavigation } from './BottomNavigation';

interface ResponsiveLayoutProps {
  children: ReactNode;
  showBottomNav?: boolean;
  activeTab?: string;
  onTabChange?: (tab: string) => void;
}

export function ResponsiveLayout({
  children,
  showBottomNav = false,
  activeTab,
  onTabChange
}: ResponsiveLayoutProps) {

  return (
    <div className="min-h-screen bg-background transition-colors duration-300 font-['Poppins',sans-serif]">
      {/* Enhanced Header with fixed backdrop filter */}
      <header className="sticky top-0 z-50 border-b bg-background/95 backdrop-blur-sm supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4">
          <div className="flex h-16 items-center justify-between">
            {/* Logo Section */}
            <div className="flex items-center gap-4">
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-r from-primary/20 to-secondary/20 rounded-lg blur-lg animate-pulse"></div>
                <img 
                  src="/icons/icon-192.png" 
                  alt="Kalaso Football Predictions Logo" 
                  className="relative h-12 w-16 object-contain rounded-lg border-2 border-primary/20 shadow-lg bg-white dark:bg-gray-800 p-1" 
                />
              </div>
              <div className="flex flex-col">
                <h1 className="text-xl font-bold bg-gradient-to-r from-primary to-primary/70 bg-clip-text text-transparent">
                  Kalaso Football Predictions
                </h1>
                <p className="text-xs text-muted-foreground hidden sm:block">
                  Your Success Partner
                </p>
              </div>
            </div>

            {/* Actions Section */}
            <div className="flex items-center gap-2">
              {/* Reserved for future features */}
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-6 pb-24">
        {children}
      </main>

      {/* Bottom Navigation */}
      {showBottomNav && <BottomNavigation activeTab={activeTab} onTabChange={onTabChange} />}
    </div>
  );
}
