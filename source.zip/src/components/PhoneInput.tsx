
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';

interface PhoneInputProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  className?: string;
}

export function PhoneInput({ value, onChange, placeholder = "Enter phone number", className }: PhoneInputProps) {
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    // Remove any non-numeric characters
    const numericValue = e.target.value.replace(/[^0-9]/g, '');
    
    // Format for Uganda phone numbers
    let formattedValue = numericValue;
    
    // If it starts with 0, replace with 256
    if (numericValue.startsWith('0') && numericValue.length > 1) {
      formattedValue = '256' + numericValue.slice(1);
    }
    
    // If it doesn't start with 256 and has 9 digits, add 256 prefix
    if (!numericValue.startsWith('256') && numericValue.length === 9) {
      formattedValue = '256' + numericValue;
    }
    
    // Limit to 12 digits max (256 + 9 digits)
    if (formattedValue.length > 12) {
      formattedValue = formattedValue.slice(0, 12);
    }
    
    onChange(formattedValue);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    // Allow: backspace, delete, tab, escape, enter, and numbers
    if ([8, 9, 27, 13, 46].indexOf(e.keyCode) !== -1 ||
        // Allow Ctrl+A, Ctrl+C, Ctrl+V, Ctrl+X
        (e.keyCode === 65 && e.ctrlKey === true) ||
        (e.keyCode === 67 && e.ctrlKey === true) ||
        (e.keyCode === 86 && e.ctrlKey === true) ||
        (e.keyCode === 88 && e.ctrlKey === true) ||
        // Allow home, end, left, right
        (e.keyCode >= 35 && e.keyCode <= 39)) {
      return;
    }
    
    // Ensure that it is a number and stop the keypress
    if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
      e.preventDefault();
    }
  };

  return (
    <Input
      type="tel"
      value={value}
      onChange={handleChange}
      onKeyDown={handleKeyDown}
      placeholder={placeholder}
      className={cn("text-left", className)}
      inputMode="numeric"
      pattern="[0-9]*"
    />
  );
}
