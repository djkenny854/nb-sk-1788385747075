import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';
import { useState } from 'react';
import { getCallbackDomain } from '@/utils/domainConfig';
import { Capacitor } from '@capacitor/core';
import { 
  authenticateWithNativeGoogle, 
  GOOGLE_WEB_CLIENT_ID,
  GOOGLE_IOS_CLIENT_ID 
} from '@/utils/nativeGoogleAuth';
import { useNavigate } from 'react-router-dom';

export function GoogleSignInButton() {
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleGoogleSignIn = async () => {
    try {
      setLoading(true);
      
      // Check if we're running in a native Capacitor environment
      if (Capacitor.isNativePlatform()) {
        console.log('Using native Google Sign-In...');
        
        // Use native Google Sign-In on Android/iOS
        const result = await authenticateWithNativeGoogle(
          GOOGLE_WEB_CLIENT_ID,
          GOOGLE_IOS_CLIENT_ID
        );
        
        if (result.success) {
          console.log('Native Google Sign-In successful!');
          toast({
            title: "Welcome!",
            description: "You have successfully signed in.",
          });
          // Navigate to the app
          navigate('/app');
        } else {
          console.error('Native Google Sign-In failed:', result.error);
          toast({
            title: "Sign In Failed",
            description: result.error || "Failed to sign in with Google. Please try again.",
            variant: "destructive"
          });
        }
      } else {
        // Use OAuth redirect flow on web
        const redirectUrl = `${getCallbackDomain()}/auth`;
        console.log('Initiating Google sign in... redirectTo:', redirectUrl);
        
        const { error } = await supabase.auth.signInWithOAuth({
          provider: 'google',
          options: {
            redirectTo: redirectUrl,
            queryParams: {
              access_type: 'offline',
              prompt: 'consent',
            },
          }
        });

        if (error) {
          console.error('Google sign in error:', error);
          toast({
            title: "Sign In Failed",
            description: error.message || "Failed to sign in with Google. Please try again.",
            variant: "destructive"
          });
        } else {
          console.log('Google OAuth initiated successfully');
        }
      }
    } catch (error: any) {
      console.error('Google sign in catch error:', error);
      toast({
        title: "Sign In Failed",
        description: "An unexpected error occurred. Please try again.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Button
      type="button"
      variant="outline"
      className="w-full h-10 text-sm font-bold bg-white hover:bg-gray-100 text-black border-0 rounded-full transition-all duration-200"
      onClick={handleGoogleSignIn}
      disabled={loading}
    >
      <div className="flex items-center justify-center gap-2">
        <svg className="w-5 h-5" viewBox="0 0 24 24">
          <path
            fill="#4285f4"
            d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
          />
          <path
            fill="#34a853"
            d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
          />
          <path
            fill="#fbbc05"
            d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
          />
          <path
            fill="#ea4335"
            d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
          />
        </svg>
        {loading ? 'Signing in...' : 'Sign up with Google'}
      </div>
    </Button>
  );
}
