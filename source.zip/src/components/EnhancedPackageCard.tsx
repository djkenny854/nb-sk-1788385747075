
import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Trophy, Clock, Star, CheckCircle } from 'lucide-react';
import { useScrollReveal } from '@/hooks/useScrollReveal';
import { Skeleton } from '@/components/ui/skeleton';

interface PackageType {
  id: string;
  name: string;
  description: string;
  duration_days: number;
  price_ugx: number;
  status: string;
}

interface EnhancedPackageCardProps {
  packageItem?: PackageType;
  index: number;
  isLoading?: boolean;
  isSubscribed?: boolean;
}

const PackageCardSkeleton = () => (
  <div className="bg-white rounded-3xl border border-gray-100 shadow-lg p-8 animate-pulse">
    <div className="flex items-center justify-between mb-6">
      <div className="flex items-center space-x-3">
        <Skeleton className="h-8 w-8 rounded-full" />
        <Skeleton className="h-6 w-32" />
      </div>
      <Skeleton className="h-6 w-16 rounded-full" />
    </div>
    
    <div className="space-y-4 mb-6">
      <Skeleton className="h-4 w-full" />
      <Skeleton className="h-4 w-3/4" />
      <Skeleton className="h-4 w-1/2" />
    </div>

    <div className="flex items-center justify-between mb-8">
      <div className="space-y-2">
        <Skeleton className="h-4 w-20" />
        <Skeleton className="h-6 w-24" />
      </div>
      <div className="space-y-2">
        <Skeleton className="h-4 w-16" />
        <Skeleton className="h-8 w-32" />
      </div>
    </div>

    <Skeleton className="h-12 w-full rounded-xl" />
  </div>
);

export function EnhancedPackageCard({ 
  packageItem, 
  index, 
  isLoading = false, 
  isSubscribed = false 
}: EnhancedPackageCardProps) {
  const { ref, isVisible } = useScrollReveal(0.1);
  const [hasAnimated, setHasAnimated] = useState(false);

  useEffect(() => {
    if (isVisible && !hasAnimated) {
      setHasAnimated(true);
    }
  }, [isVisible, hasAnimated]);

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-UG', {
      style: 'currency',
      currency: 'UGX',
      minimumFractionDigits: 0
    }).format(price);
  };

  const getPackageIcon = (name: string) => {
    const lowercaseName = name.toLowerCase();
    if (lowercaseName.includes('vip') || lowercaseName.includes('premium')) {
      return <Star className="w-5 h-5 text-gray-600" />;
    }
    if (lowercaseName.includes('gold')) {
      return <Trophy className="w-5 h-5 text-gray-700" />;
    }
    return <Trophy className="w-5 h-5 text-blue-600" />;
  };

  if (isLoading) {
    return <PackageCardSkeleton />;
  }

  if (!packageItem) {
    return null;
  }

  return (
    <div
      ref={ref}
      className={`
        bg-white rounded-3xl border border-gray-100 shadow-lg hover:shadow-2xl 
        transition-all duration-500 p-8 card-hover relative overflow-hidden
        ${hasAnimated ? 'scroll-reveal' : 'opacity-0'}
        ${isSubscribed ? 'ring-2 ring-green-500 bg-green-50' : ''}
      `}
      style={{
        animationDelay: `${index * 150}ms`
      }}
    >
      {/* Gradient overlay for subscribed packages */}
      {isSubscribed && (
        <div className="absolute top-0 right-0 bg-gradient-to-bl from-green-500 to-green-600 text-white px-4 py-2 rounded-bl-2xl">
          <div className="flex items-center space-x-1 text-sm font-medium">
            <CheckCircle className="w-4 h-4" />
            <span>Active</span>
          </div>
        </div>
      )}

      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-gradient-to-br from-blue-100 to-purple-100 rounded-2xl flex items-center justify-center">
            {getPackageIcon(packageItem.name)}
          </div>
          <h3 className="text-xl font-bold text-gray-900 font-heading">
            {packageItem.name}
          </h3>
        </div>
        <div className="bg-gradient-to-r from-green-100 to-blue-100 text-green-800 px-3 py-1 rounded-full text-sm font-medium">
          Popular
        </div>
      </div>
      
      <p className="text-gray-600 mb-8 leading-relaxed">
        {packageItem.description || "Premium football predictions with expert analysis and detailed insights for maximum winning potential."}
      </p>

      <div className="flex items-center justify-between mb-8">
        <div className="space-y-2">
          <p className="text-sm text-gray-500 font-medium">Duration</p>
          <div className="flex items-center space-x-2">
            <Clock className="w-5 h-5 text-blue-600" />
            <span className="font-bold text-gray-900 text-lg">
              {packageItem.duration_days} days
            </span>
          </div>
        </div>
        <div className="text-right space-y-2">
          <p className="text-sm text-gray-500 font-medium">Price</p>
          <div className="text-3xl font-bold gradient-text">
            {formatPrice(packageItem.price_ugx)}
          </div>
        </div>
      </div>
      
      <Link to="/auth" className="block">
        <button className={`
          w-full py-4 rounded-2xl font-bold text-lg transition-all duration-300
          ${isSubscribed 
            ? 'bg-green-600 hover:bg-green-700 text-white' 
            : 'bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white hover:shadow-lg'
          }
        `}>
          {isSubscribed ? 'Manage Subscription' : 'Subscribe Now'}
        </button>
      </Link>
    </div>
  );
}
