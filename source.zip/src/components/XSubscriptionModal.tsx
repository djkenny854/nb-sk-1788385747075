import { useState, useEffect, useMemo, useCallback } from 'react';
import { Dialog, DialogContent, DialogTitle } from '@/components/ui/dialog';
import { Drawer, DrawerContent, DrawerTitle } from '@/components/ui/drawer';
import { ThinSlider } from '@/components/ui/thin-slider';
import { X, Pencil, Check } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useIsMobile } from '@/hooks/use-mobile';
import { LoadingSpinner } from './LoadingSpinner';

interface Package {
  id: string;
  name: string;
  description: string;
  duration_days: number;
  price_ugx: number;
  status: string;
}

export type SubscribePaymentStatus = 'idle' | 'processing' | 'success';

interface XSubscriptionModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  packageItem: Package | null;
  isCurrentlySubscribed: boolean;
  onConfirm: (days: number, price: number) => void;
  phoneNumber?: string;
  onEditPhone?: () => void;
  onSavePhone?: (phone: string) => Promise<boolean>;
  paymentStatus?: SubscribePaymentStatus;
}

const TIPS_PER_DAY = 2;

const triggerHaptic = () => {
  if ('vibrate' in navigator) navigator.vibrate(8);
};

const formatPrice = (price: number) =>
  new Intl.NumberFormat('en-UG', {
    style: 'currency',
    currency: 'UGX',
    minimumFractionDigits: 0,
  }).format(price);

export function XSubscriptionModal({
  open,
  onOpenChange,
  packageItem,
  isCurrentlySubscribed,
  onConfirm,
  phoneNumber,
  onSavePhone,
  paymentStatus = 'idle',
}: XSubscriptionModalProps) {
  const isMobile = useIsMobile();
  const [selectedDays, setSelectedDays] = useState(30);
  const [editingPhone, setEditingPhone] = useState(false);
  const [phoneDraft, setPhoneDraft] = useState('');
  const [savingPhone, setSavingPhone] = useState(false);

  const minDays = packageItem?.duration_days ?? 7;
  const maxDays = Math.min(180, Math.max(minDays * 4, minDays + 30));

  useEffect(() => {
    if (open && packageItem) {
      setSelectedDays(packageItem.duration_days);
      setEditingPhone(false);
      setPhoneDraft(phoneNumber || '');
    }
  }, [open, packageItem, phoneNumber]);

  const basePricePerDay = useMemo(() => {
    if (!packageItem) return 0;
    return Math.round(packageItem.price_ugx / packageItem.duration_days);
  }, [packageItem]);

  const totalPrice = useMemo(() => {
    if (!packageItem) return 0;
    if (selectedDays === packageItem.duration_days) return packageItem.price_ugx;
    return Math.max(500, Math.round(basePricePerDay * selectedDays));
  }, [basePricePerDay, packageItem, selectedDays]);

  const ticketRange = useMemo(() => {
    const low = Math.max(1, Math.round(selectedDays * TIPS_PER_DAY * 0.8));
    const high = Math.round(selectedDays * TIPS_PER_DAY * 1.2);
    return `${low} – ${high}`;
  }, [selectedDays]);

  const locked = paymentStatus !== 'idle';

  const handleSliderChange = useCallback((value: number[]) => {
    triggerHaptic();
    setSelectedDays(value[0]);
  }, []);

  const handleSavePhone = async () => {
    if (!onSavePhone) {
      setEditingPhone(false);
      return;
    }
    setSavingPhone(true);
    const ok = await onSavePhone(phoneDraft.trim());
    setSavingPhone(false);
    if (ok) setEditingPhone(false);
  };

  if (!packageItem) return null;

  const title = isCurrentlySubscribed ? 'Extend subscription' : 'Subscribe';

  const body = (
    <div className="flex flex-col">
      {/* Header */}
      <div className="relative flex items-center justify-center px-4 pb-4 pt-4">
        <button
          onClick={() => !locked && onOpenChange(false)}
          disabled={locked}
          aria-label="Close"
          className="absolute left-3 rounded-full p-2 text-foreground transition-colors hover:bg-muted disabled:opacity-40"
        >
          <X className="h-5 w-5" />
        </button>
        <h2 className="text-lg font-bold">{title}</h2>
      </div>

      <div className={cn('space-y-7 px-6 pb-6', locked && 'pointer-events-none opacity-70')}>
        {/* Package */}
        <div className="flex items-center justify-between gap-4">
          <span className="text-[15px] text-muted-foreground">Package</span>
          <span className="truncate text-[15px] font-bold text-foreground">{packageItem.name}</span>
        </div>

        {/* Access + rate */}
        <div className="flex items-center justify-between gap-4">
          <span className="text-[15px] text-muted-foreground">Daily rate</span>
          <span className="text-[15px] font-bold text-foreground">{formatPrice(basePricePerDay)}</span>
        </div>

        {/* Duration slider */}
        <div>
          <div className="mb-2 flex items-center justify-between">
            <span className="text-[15px] text-muted-foreground">Duration</span>
            <span className="text-[15px] font-bold text-foreground">{selectedDays} days</span>
          </div>
          <ThinSlider
            value={[selectedDays]}
            onValueChange={handleSliderChange}
            min={minDays}
            max={maxDays}
            step={1}
            disabled={locked}
          />
          <div className="mt-1 flex justify-between text-xs text-muted-foreground">
            <span>{minDays} days</span>
            <span>{maxDays} days</span>
          </div>
        </div>

        {/* Total */}
        <div className="flex items-center justify-between gap-4">
          <span className="text-[15px] text-muted-foreground">Total</span>
          <span className="text-[15px] font-bold text-foreground">{formatPrice(totalPrice)}</span>
        </div>

        {/* Pay with */}
        {editingPhone ? (
          <div className="relative pt-1">
            <input
              id="pay-phone"
              value={phoneDraft}
              onChange={(e) => setPhoneDraft(e.target.value)}
              placeholder=" "
              disabled={savingPhone || locked}
              className="peer h-14 w-full rounded-lg border border-border bg-transparent px-4 pt-4 text-[15px] text-foreground outline-none transition-colors focus:border-primary focus:ring-1 focus:ring-primary"
            />
            <label
              htmlFor="pay-phone"
              className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 bg-background px-1 text-[15px] text-muted-foreground transition-all peer-focus:top-0 peer-focus:text-xs peer-focus:text-primary peer-[:not(:placeholder-shown)]:top-0 peer-[:not(:placeholder-shown)]:text-xs"
            >
              Phone number
            </label>
            <div className="mt-3 flex justify-end gap-2">
              <button
                onClick={() => { setEditingPhone(false); setPhoneDraft(phoneNumber || ''); }}
                className="rounded-full px-4 py-2 text-sm font-bold text-muted-foreground hover:bg-muted"
              >
                Cancel
              </button>
              <button
                onClick={handleSavePhone}
                disabled={savingPhone}
                className="rounded-full bg-primary px-4 py-2 text-sm font-bold text-primary-foreground disabled:opacity-60"
              >
                {savingPhone ? 'Saving…' : 'Save'}
              </button>
            </div>
          </div>
        ) : (
          <div className="flex items-center justify-between gap-4">
            <span className="text-[15px] text-muted-foreground">Pay with</span>
            <button
              onClick={() => setEditingPhone(true)}
              disabled={locked}
              className="flex items-center gap-2 text-[15px] font-bold text-foreground disabled:opacity-60"
            >
              {phoneNumber || 'Add phone number'}
              <Pencil className="h-4 w-4 text-muted-foreground" />
            </button>
          </div>
        )}

        {/* Estimated tickets */}
        <div className="flex items-center justify-between gap-4 border-t border-border pt-5">
          <span className="text-[15px] font-bold text-foreground">Est. tickets</span>
          <span className="text-[15px] font-bold text-foreground">
            {ticketRange}{' '}
            <span className="font-normal text-muted-foreground">over {selectedDays} days</span>
          </span>
        </div>
      </div>

      {/* CTA */}
      <div className="px-6 pb-7">
        <button
          onClick={() => {
            triggerHaptic();
            onConfirm(selectedDays, totalPrice);
          }}
          disabled={locked || !phoneNumber}
          className={cn(
            'flex h-14 w-full items-center justify-center gap-2 rounded-full text-[17px] font-bold transition-colors',
            paymentStatus === 'success'
              ? 'bg-green-600 text-white'
              : 'bg-foreground text-background hover:bg-foreground/90',
            (locked || !phoneNumber) && paymentStatus !== 'success' && 'opacity-70'
          )}
        >
          {paymentStatus === 'processing' && <LoadingSpinner size="sm" variant="google" className="gap-0" />}
          {paymentStatus === 'success' && <Check className="h-5 w-5" />}
          {paymentStatus === 'idle' && 'Proceed to payment'}
          {paymentStatus === 'processing' && 'Awaiting confirmation…'}
          {paymentStatus === 'success' && 'Thanks, payment received'}
        </button>
        <p className="mt-3 text-center text-xs text-muted-foreground">
          By continuing you agree to our{' '}
          <a href="/terms" className="text-primary hover:underline">Terms and Conditions</a>.
        </p>
      </div>
    </div>
  );

  if (isMobile) {
    return (
      <Drawer open={open} onOpenChange={(v) => { if (!locked) onOpenChange(v); }}>
        <DrawerContent className="max-h-[92vh] overflow-y-auto border-border bg-background">
          <DrawerTitle className="sr-only">{title}</DrawerTitle>
          {body}
        </DrawerContent>
      </Drawer>
    );
  }

  return (
    <Dialog open={open} onOpenChange={(v) => { if (!locked) onOpenChange(v); }}>
      <DialogContent className="max-w-lg gap-0 overflow-hidden rounded-2xl border-border bg-background p-0 [&>button]:hidden">
        <DialogTitle className="sr-only">{title}</DialogTitle>
        {body}
      </DialogContent>
    </Dialog>
  );
}
