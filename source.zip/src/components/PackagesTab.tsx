import { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { Check, Search, X, AlertCircle, Trophy, BellRing, LineChart, Headphones, ShieldCheck } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

import { XSubscriptionModal, type SubscribePaymentStatus } from './XSubscriptionModal';
import { useNylonPayment } from '@/hooks/useNylonPayment';
import { useSubscriptions } from '@/hooks/useSubscriptions';
import { PageTransition } from './PageTransition';
import { cn } from '@/lib/utils';

interface Package {
  id: string;
  name: string;
  description: string;
  duration_days: number;
  price_ugx: number;
  status: string;
}

const FEATURES = [
  { icon: Trophy, label: 'Expert-vetted daily tickets' },
  { icon: LineChart, label: 'Full performance history & stats' },
  { icon: BellRing, label: 'Instant alerts when tips drop' },
  { icon: ShieldCheck, label: 'Verified win/loss tracking' },
  { icon: Headphones, label: 'Priority support' },
];

export function PackagesTab() {
  const { user } = useAuth();
  const { toast } = useToast();
  const { subscriptions, hasActiveSubscription, getActivePackageIds } = useSubscriptions();
  const [packages, setPackages] = useState<Package[]>([]);
  const [filteredPackages, setFilteredPackages] = useState<Package[]>([]);
  const [loading, setLoading] = useState(true);
  const [phoneNumber, setPhoneNumber] = useState('');
  const [phoneDialogOpen, setPhoneDialogOpen] = useState(false);
  const [selectedPackage, setSelectedPackage] = useState<Package | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [subscriptionModalOpen, setSubscriptionModalOpen] = useState(false);
  const [packageToSubscribe, setPackageToSubscribe] = useState<Package | null>(null);
  const isProcessingPayment = useRef(false);
  const nylon = useNylonPayment();

  useEffect(() => {
    if (user) {
      fetchPackages();
      fetchUserProfile();
    }
  }, [user]);

  useEffect(() => {
    if (!searchQuery.trim()) {
      setFilteredPackages(packages);
    } else {
      const q = searchQuery.toLowerCase();
      setFilteredPackages(
        packages.filter(
          (pkg) => pkg.name.toLowerCase().includes(q) || pkg.description?.toLowerCase().includes(q)
        )
      );
    }
  }, [packages, searchQuery]);

  const fetchUserProfile = async () => {
    if (!user) return;
    const { data: profile } = await supabase
      .from('profiles')
      .select('phone')
      .eq('id', user.id)
      .single();
    if (profile?.phone) setPhoneNumber(profile.phone);
  };

  const fetchPackages = async () => {
    const { data, error } = await supabase
      .from('packages')
      .select('*')
      .eq('status', 'active')
      .order('price_ugx', { ascending: true });
    if (error) {
      toast({ title: 'Error', description: 'Failed to load packages', variant: 'destructive' });
    } else {
      setPackages(data || []);
    }
    setLoading(false);
  };

  const validatePhoneNumber = (phone: string): { isValid: boolean; formatted?: string; error?: string } => {
    let cleanPhone = phone.replace(/[^0-9]/g, '');
    if (cleanPhone.match(/^07[0-9]{8}$/)) cleanPhone = '256' + cleanPhone.substring(1);
    if (cleanPhone.match(/^[0-9]{9}$/)) cleanPhone = '256' + cleanPhone;
    if (!cleanPhone.match(/^256[0-9]{9}$/)) {
      return {
        isValid: false,
        error: 'Please enter a valid Uganda phone number (e.g., 256701234567 or 0701234567)',
      };
    }
    return { isValid: true, formatted: cleanPhone };
  };

  const updatePhoneNumber = async (newPhone: string) => {
    if (!user) return false;
    const validation = validatePhoneNumber(newPhone);
    if (!validation.isValid) {
      toast({ title: 'Invalid Phone Number', description: validation.error, variant: 'destructive' });
      return false;
    }
    const { error } = await supabase
      .from('profiles')
      .update({ phone: validation.formatted })
      .eq('id', user.id);
    if (error) {
      toast({ title: 'Error', description: 'Failed to update phone number', variant: 'destructive' });
      return false;
    }
    setPhoneNumber(validation.formatted!);
    return true;
  };

  const handleSubscribe = (packageItem: Package) => {
    if (!user) {
      toast({
        title: 'Authentication Required',
        description: 'Please log in to subscribe to a package',
        variant: 'destructive',
      });
      return;
    }
    if (!phoneNumber || !validatePhoneNumber(phoneNumber).isValid) {
      setSelectedPackage(packageItem);
      setPhoneDialogOpen(true);
      return;
    }
    nylon.reset();
    setPackageToSubscribe(packageItem);
    setSubscriptionModalOpen(true);
  };

  const handleConfirmSubscription = async (days: number, price: number) => {
    if (!packageToSubscribe || !user) return;
    const phoneValidation = validatePhoneNumber(phoneNumber);
    if (!phoneValidation.isValid) {
      toast({ title: 'Invalid phone', description: 'Please update your phone number.', variant: 'destructive' });
      return;
    }
    if (isProcessingPayment.current) return;
    isProcessingPayment.current = true;

    const isCurrentlySubscribed = hasActiveSubscription(packageToSubscribe.id);
    try {
      await nylon.initiate({
        userId: user.id,
        packageId: packageToSubscribe.id,
        amount: price,
        phoneNumber: phoneValidation.formatted!,
        durationDays: days,
        description: isCurrentlySubscribed
          ? `${packageToSubscribe.name} - Extension (${days} days)`
          : `${packageToSubscribe.name} - ${days} days`,
      });
    } catch {
      // errors surfaced through nylon.status / toasts
    } finally {
      setTimeout(() => {
        isProcessingPayment.current = false;
      }, 1500);
    }
  };

  const handlePhoneSubmit = async () => {
    if (!phoneNumber.trim()) {
      toast({ title: 'Phone Number Required', description: 'Please enter your phone number', variant: 'destructive' });
      return;
    }
    const success = await updatePhoneNumber(phoneNumber);
    if (success) {
      setPhoneDialogOpen(false);
      if (selectedPackage) setTimeout(() => handleSubscribe(selectedPackage), 400);
    }
  };

  const formatPrice = (price: number) =>
    new Intl.NumberFormat('en-UG', { style: 'currency', currency: 'UGX', minimumFractionDigits: 0 }).format(price);

  // Payment state for the subscribe modal button
  const paymentStatus: SubscribePaymentStatus =
    nylon.status === 'completed'
      ? 'success'
      : nylon.initiating || nylon.status === 'pending'
      ? 'processing'
      : 'idle';

  useEffect(() => {
    if (nylon.status === 'completed') {
      const t = setTimeout(() => {
        setSubscriptionModalOpen(false);
        nylon.reset();
      }, 2200);
      return () => clearTimeout(t);
    }
  }, [nylon.status]);

  const activePackageIds = getActivePackageIds();

  if (loading) {
    return (
      <PageTransition>
        <div className="min-h-screen">
          <div className="sticky top-0 z-10 border-b border-border bg-background/80 px-4 py-3 backdrop-blur-md">
            <h1 className="text-xl font-bold">Packages</h1>
          </div>
          <div className="grid gap-4 p-4 md:grid-cols-2 xl:grid-cols-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="animate-pulse rounded-2xl border border-border p-6">
                <div className="mb-3 h-5 w-1/2 rounded bg-muted" />
                <div className="mb-4 h-9 w-1/3 rounded bg-muted" />
                <div className="space-y-2">
                  {[1, 2, 3, 4].map((j) => (
                    <div key={j} className="h-4 w-full rounded bg-muted" />
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </PageTransition>
    );
  }

  return (
    <PageTransition>
      <div className="min-h-screen">
        {/* Header */}
        <div className="sticky top-0 z-10 border-b border-border bg-background/80 backdrop-blur-md">
          <div className="px-4 py-3">
            <h1 className="text-xl font-bold">Packages</h1>
            <p className="text-sm text-muted-foreground">Pick the plan that fits how you bet</p>
          </div>
          <div className="px-4 pb-3">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                type="text"
                placeholder="Search packages"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="border-0 bg-muted/50 pl-11 pr-10"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  aria-label="Clear search"
                >
                  <X className="h-4 w-4" />
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Phone warning */}
        {!phoneNumber && (
          <div className="mx-4 mt-4 flex items-center gap-3 rounded-2xl border border-primary/20 bg-primary/10 p-4">
            <AlertCircle className="h-5 w-5 shrink-0 text-primary" />
            <div>
              <p className="text-sm font-bold text-foreground">Phone number required</p>
              <p className="text-sm text-muted-foreground">Add your Uganda number to pay by mobile money</p>
            </div>
          </div>
        )}

        {/* Active subscriptions */}
        {subscriptions.length > 0 && (
          <div className="mx-4 mt-4 flex flex-wrap items-center gap-2 rounded-2xl border border-border bg-muted/40 p-4">
            <span className="text-sm font-bold text-foreground">Active:</span>
            {subscriptions.map((sub, index) => (
              <span
                key={index}
                className="inline-flex items-center gap-1 rounded-full bg-primary/15 px-3 py-1 text-xs font-bold text-primary"
              >
                <Check className="h-3 w-3" />
                {sub.packages?.name}
              </span>
            ))}
          </div>
        )}

        {/* Pricing cards */}
        <div className="grid gap-4 p-4 md:grid-cols-2 xl:grid-cols-3">
          {filteredPackages.map((pkg, index) => {
            const subscribed = activePackageIds.includes(pkg.id);
            const isPopular = index === 1 || (filteredPackages.length === 1 && index === 0);
            const perDay = Math.round(pkg.price_ugx / pkg.duration_days);

            return (
              <div
                key={pkg.id}
                className={cn(
                  'relative flex flex-col rounded-2xl border p-6 transition-colors',
                  subscribed
                    ? 'border-primary bg-primary/5'
                    : isPopular
                    ? 'border-primary'
                    : 'border-border hover:border-foreground/30'
                )}
              >
                {(isPopular || subscribed) && (
                  <span className="absolute -top-3 left-6 rounded-full bg-primary px-3 py-1 text-[11px] font-bold uppercase tracking-wide text-primary-foreground">
                    {subscribed ? 'Active' : 'Most popular'}
                  </span>
                )}

                <h3 className="text-xl font-extrabold text-foreground">{pkg.name}</h3>

                <div className="mt-4 flex items-end gap-2">
                  <span className="text-3xl font-extrabold leading-none text-foreground">
                    {formatPrice(pkg.price_ugx)}
                  </span>
                  <span className="pb-1 text-sm text-muted-foreground">/ {pkg.duration_days} days</span>
                </div>
                <p className="mt-1 text-sm text-muted-foreground">
                  About {formatPrice(perDay)} a day · billed once
                </p>

                <ul className="mt-6 space-y-3">
                  {FEATURES.map(({ icon: Icon, label }) => (
                    <li key={label} className="flex items-start gap-3 text-sm text-foreground">
                      <Icon className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                      <span>{label}</span>
                    </li>
                  ))}
                </ul>

                {pkg.description && (
                  <p className="mt-5 text-sm text-muted-foreground">{pkg.description}</p>
                )}

                <div className="flex-1" />

                <Button
                  onClick={() => handleSubscribe(pkg)}
                  className={cn(
                    'mt-7 h-12 w-full rounded-full text-[15px] font-bold',
                    subscribed
                      ? 'bg-primary text-primary-foreground hover:bg-primary/90'
                      : 'bg-foreground text-background hover:bg-foreground/90'
                  )}
                >
                  {subscribed ? 'Extend subscription' : 'Subscribe'}
                </Button>
              </div>
            );
          })}
        </div>

        {filteredPackages.length === 0 && (
          <p className="px-4 py-10 text-center text-sm text-muted-foreground">No packages match your search.</p>
        )}

        {/* Phone dialog */}
        <Dialog open={phoneDialogOpen} onOpenChange={setPhoneDialogOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Phone number required</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="phone">Uganda phone number</Label>
                <Input
                  id="phone"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  placeholder="e.g., 0701234567"
                  className="mt-2"
                />
              </div>
              <Button onClick={handlePhoneSubmit} className="h-12 w-full rounded-full font-bold">
                Continue to payment
              </Button>
            </div>
          </DialogContent>
        </Dialog>

        {/* Subscribe / boost-style modal */}
        <XSubscriptionModal
          open={subscriptionModalOpen}
          onOpenChange={setSubscriptionModalOpen}
          packageItem={packageToSubscribe}
          isCurrentlySubscribed={packageToSubscribe ? hasActiveSubscription(packageToSubscribe.id) : false}
          onConfirm={handleConfirmSubscription}
          phoneNumber={phoneNumber}
          onEditPhone={() => setPhoneDialogOpen(true)}
          onSavePhone={updatePhoneNumber}
          paymentStatus={paymentStatus}
        />
      </div>
    </PageTransition>
  );
}
