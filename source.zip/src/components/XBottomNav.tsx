import { NavLink, useLocation } from 'react-router-dom'
import { Home, Bell, Target, Gift, Shield } from 'lucide-react'
import { cn } from '@/lib/utils'
import { useState, useEffect, useRef } from 'react'
import { useNewTipsIndicator } from '@/hooks/useNewTipsIndicator'

const navItems = [
  { icon: Home, path: '/app' },
  { icon: Target, path: '/app/tips' },
  { icon: Gift, path: '/app/free-tips' },
  { icon: Shield, path: '/app/packages' },
  { icon: Bell, path: '/app/notifications' },
]

export function XBottomNav() {
  const location = useLocation()
  const [isVisible, setIsVisible] = useState(true)
  const lastScrollY = useRef(0)
  const { newTipsCount, markTipsAsViewed } = useNewTipsIndicator()

  useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY
      const scrollDifference = currentScrollY - lastScrollY.current

      // Only hide/show when scrolling more than 10px to prevent jitter
      if (Math.abs(scrollDifference) > 10) {
        if (scrollDifference > 0 && currentScrollY > 60) {
          // Scrolling down - hide nav
          setIsVisible(false)
        } else {
          // Scrolling up - show nav
          setIsVisible(true)
        }
        lastScrollY.current = currentScrollY
      }
    }

    window.addEventListener('scroll', handleScroll, { passive: true })
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  const isActive = (path: string) => {
    if (path === '/app') {
      return location.pathname === '/app'
    }
    return location.pathname.startsWith(path)
  }

  const handleNavClick = (path: string) => {
    // Clear new tips indicator when navigating to tips page
    if (path === '/app/tips') {
      markTipsAsViewed()
    }
  }

  return (
    <nav 
      className={cn(
        "fixed bottom-0 left-0 right-0 bg-background border-t border-border z-50 transition-transform duration-300",
        isVisible ? "translate-y-0" : "translate-y-full"
      )}
      style={{ paddingBottom: 'env(safe-area-inset-bottom, 0px)' }}
    >
      <div className="flex items-center justify-around h-16 px-1">
        {navItems.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            onClick={() => handleNavClick(item.path)}
            className="flex-1 flex items-center justify-center h-full"
            aria-label={item.path === '/app' ? 'Home' : item.path.split('/').pop()?.replace('-', ' ')}
          >
            <div className="relative p-2 rounded-full hover:bg-muted/80 transition-colors">
              <item.icon 
                className={cn(
                  "w-7 h-7",
                  isActive(item.path) ? "text-foreground" : "text-muted-foreground"
                )} 
                strokeWidth={isActive(item.path) ? 2.5 : 1.75}
              />
              {/* New tips count badge */}
              {item.path === '/app/tips' && newTipsCount > 0 && (
                <span className="absolute -top-0.5 -right-1 flex h-5 min-w-[20px] items-center justify-center rounded-full border-2 border-background bg-primary px-1 text-[10px] font-bold leading-none text-primary-foreground">
                  {newTipsCount > 99 ? '99+' : newTipsCount}
                </span>
              )}
            </div>
          </NavLink>
        ))}
      </div>
    </nav>
  )
}
