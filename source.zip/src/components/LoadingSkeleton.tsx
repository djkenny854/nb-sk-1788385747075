import { Skeleton } from '@/components/ui/skeleton';

export function TipLoadingSkeleton() {
  return (
    <div className="space-y-3">
      {[1, 2, 3].map((i) => (
        <div key={i} className="border rounded-lg p-4 animate-pulse">
          <div className="flex items-center gap-4">
            {/* Image skeleton */}
            <div className="w-20 h-16 bg-muted rounded-lg flex-shrink-0" />
            
            {/* Content skeleton */}
            <div className="flex-1 space-y-2">
              <div className="flex justify-between items-start">
                <div className="space-y-1">
                  <Skeleton className="h-5 w-32 animate-shimmer" />
                  <Skeleton className="h-4 w-20 animate-shimmer" />
                </div>
                <Skeleton className="h-6 w-16 rounded-full animate-shimmer" />
              </div>
              
              {/* Matches skeleton */}
              <div className="flex gap-2">
                <Skeleton className="h-6 w-24 rounded animate-shimmer" />
                <Skeleton className="h-6 w-28 rounded animate-shimmer" />
              </div>
              
              {/* Comments skeleton */}
              <Skeleton className="h-3 w-full animate-shimmer" />
            </div>
            
            {/* Action buttons skeleton */}
            <div className="flex flex-col gap-2">
              <Skeleton className="h-8 w-16 animate-shimmer" />
              <Skeleton className="h-8 w-16 animate-shimmer" />
              <Skeleton className="h-8 w-16 animate-shimmer" />
            </div>
          </div>
          
          {/* Platform buttons skeleton */}
          <div className="flex gap-2 mt-3 pt-3 border-t">
            <Skeleton className="h-8 flex-1 animate-shimmer" />
            <Skeleton className="h-8 flex-1 animate-shimmer" />
          </div>
          
          {/* Timestamp skeleton */}
          <Skeleton className="h-3 w-20 mt-2 animate-shimmer" />
        </div>
      ))}
    </div>
  );
}

export function DashboardLoadingSkeleton() {
  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
      {[1, 2, 3].map((i) => (
        <div key={i} className="border rounded-lg p-6 animate-pulse">
          <div className="space-y-4">
            {/* Header skeleton */}
            <div className="flex justify-between items-start">
              <Skeleton className="h-6 w-24 animate-shimmer" />
              <Skeleton className="h-5 w-16 rounded-full animate-shimmer" />
            </div>
            
            {/* Circular progress skeleton */}
            <div className="relative w-32 h-32 mx-auto">
              <div className="w-32 h-32 border-8 border-muted rounded-full animate-shimmer" />
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <Skeleton className="h-6 w-8 animate-shimmer" />
                <Skeleton className="h-3 w-12 animate-shimmer" />
              </div>
            </div>
            
            {/* Time details skeleton */}
            <div className="space-y-2">
              {[1, 2, 3].map((j) => (
                <div key={j} className="flex justify-between items-center">
                  <Skeleton className="h-4 w-8 animate-shimmer" />
                  <Skeleton className="h-6 w-6 animate-shimmer" />
                </div>
              ))}
            </div>
            
            {/* Footer skeleton */}
            <div className="pt-2 border-t">
              <Skeleton className="h-3 w-24 animate-shimmer" />
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

export function TransactionLoadingSkeleton() {
  return (
    <div className="space-y-4">
      {/* Summary cards skeleton */}
      <div className="grid gap-4 md:grid-cols-3">
        {[1, 2, 3].map((i) => (
          <div key={i} className="border rounded-lg p-6 animate-pulse">
            <div className="flex justify-between items-center mb-4">
              <Skeleton className="h-4 w-20 animate-shimmer" />
              <Skeleton className="h-4 w-4 animate-shimmer" />
            </div>
            <Skeleton className="h-8 w-16 mb-2 animate-shimmer" />
            <Skeleton className="h-3 w-24 animate-shimmer" />
          </div>
        ))}
      </div>
      
      {/* Table skeleton */}
      <div className="border rounded-lg p-6">
        <div className="space-y-4">
          <Skeleton className="h-6 w-32 animate-shimmer" />
          <Skeleton className="h-4 w-48 animate-shimmer" />
          
          {/* Search and filter skeleton */}
          <div className="flex gap-4">
            <Skeleton className="h-10 flex-1 animate-shimmer" />
            <Skeleton className="h-10 w-32 animate-shimmer" />
          </div>
          
          {/* Table rows skeleton */}
          <div className="space-y-3">
            {[1, 2, 3, 4, 5].map((i) => (
              <div key={i} className="flex gap-4 py-3 border-b">
                <Skeleton className="h-4 w-20 animate-shimmer" />
                <Skeleton className="h-4 w-24 animate-shimmer" />
                <Skeleton className="h-4 w-32 animate-shimmer" />
                <Skeleton className="h-4 w-20 animate-shimmer" />
                <Skeleton className="h-4 w-24 animate-shimmer" />
                <Skeleton className="h-4 w-16 animate-shimmer" />
                <Skeleton className="h-4 w-28 animate-shimmer" />
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}