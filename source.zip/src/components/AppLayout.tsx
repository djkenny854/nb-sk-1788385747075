import { ReactNode, useState } from 'react'
import { SidebarProvider, SidebarTrigger } from '@/components/ui/sidebar'
import { AppSidebar } from './AppSidebar'
import { Search, HelpCircle, Grid3X3, User } from 'lucide-react'
import { GetAppModal } from './GetAppModal'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { useAuth } from '@/hooks/useAuth'
import { useCapacitorDetection } from '@/hooks/useCapacitorDetection'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { supabase } from '@/integrations/supabase/client'
import { useNavigate } from 'react-router-dom'
import { NotificationDropdown } from './NotificationDropdown'

interface AppLayoutProps {
  children: ReactNode
}

export function AppLayout({ children }: AppLayoutProps) {
  const { user } = useAuth()
  const navigate = useNavigate()
  const { isNative } = useCapacitorDetection()
  const [getAppModalOpen, setGetAppModalOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState('')

  const handleSignOut = async () => {
    await supabase.auth.signOut()
    navigate('/auth')
  }

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full bg-background">
        <AppSidebar />
        
        <main className="flex-1 flex flex-col bg-background">
          {/* Header */}
          <header className="h-16 bg-background flex items-center justify-between px-4 lg:px-6">
            <div className="flex items-center gap-4 flex-1">
              <SidebarTrigger className="h-10 w-10 hover:bg-muted rounded-full lg:hidden" />
              
              {/* Search Bar - Google Style */}
              <div className="relative flex-1 max-w-2xl">
                <div className="absolute inset-y-0 left-0 flex items-center pl-4 pointer-events-none">
                  <Search className="h-5 w-5 text-muted-foreground" />
                </div>
                <Input
                  type="text"
                  placeholder="Search Kalaso Football Predictions"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full h-12 pl-12 pr-4 bg-muted/50 border-0 rounded-lg text-[15px] placeholder:text-muted-foreground focus-visible:ring-1 focus-visible:ring-border focus-visible:bg-background"
                />
              </div>
            </div>

            <div className="flex items-center gap-1 ml-4">
              {/* Help Icon */}
              <Button 
                variant="ghost" 
                size="icon"
                className="h-10 w-10 rounded-full hover:bg-muted"
              >
                <HelpCircle className="h-5 w-5 text-muted-foreground" />
              </Button>

              {/* Apps Grid Icon - Hidden in native Capacitor environment */}
              {!isNative && (
                <Button 
                  variant="ghost" 
                  size="icon"
                  onClick={() => setGetAppModalOpen(true)}
                  className="h-10 w-10 rounded-full hover:bg-muted"
                >
                  <Grid3X3 className="h-5 w-5 text-muted-foreground" />
                </Button>
              )}

              {/* User Avatar */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="h-10 w-10 rounded-full hover:bg-muted p-0 ml-2">
                    <Avatar className="h-8 w-8">
                      <AvatarImage src={user?.user_metadata?.avatar_url} />
                      <AvatarFallback className="bg-primary text-primary-foreground text-sm font-medium">
                        {user?.email?.[0]?.toUpperCase() || <User className="h-4 w-4" />}
                      </AvatarFallback>
                    </Avatar>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuLabel>
                    <div className="flex flex-col space-y-1">
                      <p className="text-sm font-medium leading-none">
                        {user?.user_metadata?.full_name || user?.email}
                      </p>
                      <p className="text-xs leading-none text-muted-foreground">
                        {user?.email}
                      </p>
                    </div>
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => navigate('/app/profile')}>
                    Profile Settings
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => navigate('/app/packages')}>
                    Manage Subscription
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleSignOut}>
                    Sign out
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </header>

          {/* Main Content */}
          <div className="flex-1 bg-background overflow-auto">
            {children}
          </div>
        </main>
      </div>

      {/* Get App Modal */}
      <GetAppModal 
        open={getAppModalOpen}
        onOpenChange={setGetAppModalOpen}
      />
    </SidebarProvider>
  )
}
